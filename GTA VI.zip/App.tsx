import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine } from './game/GameEngine';
import { HUD } from './components/HUD';
import { MainMenu } from './components/MainMenu';
import { VictoryScreen } from './components/VictoryScreen';
import { CustomizationMenu } from './components/CustomizationMenu';
import { InteractionMenu } from './components/InteractionMenu';
import { PauseMenu } from './components/PauseMenu';
import { Character, PlayerState, VehicleCustomizationData, NPCData, GameSettings } from './types';
import { CHARACTERS } from './game/constants';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const minimapRef = useRef<HTMLCanvasElement>(null);
  const gameEngineRef = useRef<GameEngine | null>(null);

  const [gameState, setGameState] = useState<'MENU' | 'PLAYING' | 'PAUSED' | 'VICTORY' | 'GAMEOVER'>('MENU');
  const [selectedCharIndex, setSelectedCharIndex] = useState(0);
  const [gameSettings, setGameSettings] = useState<GameSettings>({
    musicVolume: 0.5,
    sfxVolume: 0.8,
    sensitivity: 1.0,
    renderDistance: 'MEDIUM'
  });
  
  // HUD State
  const [playerState, setPlayerState] = useState<PlayerState | null>(null);
  const [currentCharacter, setCurrentCharacter] = useState<Character>(CHARACTERS[0]);
  const [notification, setNotification] = useState<string | null>(null);
  const [isCollisionWarning, setIsCollisionWarning] = useState(false);
  const [isInVehicle, setIsInVehicle] = useState(false);
  const [interactLabel, setInteractLabel] = useState<string | null>(null);
  const [vehicleSpeed, setVehicleSpeed] = useState(0);

  // Customization & Interaction State
  const [isCustomizing, setIsCustomizing] = useState(false);
  const [activeNPC, setActiveNPC] = useState<NPCData | null>(null);
  const [customizationData, setCustomizationData] = useState<VehicleCustomizationData>({ color: 0xffffff, wheelType: 0 });

  const handleStartGame = () => {
    if (gameEngineRef.current) {
      gameEngineRef.current.startGame(selectedCharIndex);
      setGameState('PLAYING');
      setCurrentCharacter(CHARACTERS[selectedCharIndex]);
    }
  };

  const handleRestart = () => {
    window.location.reload();
  };

  const handleSettingsUpdate = (newSettings: GameSettings) => {
      setGameSettings(newSettings);
      if (gameEngineRef.current) {
          gameEngineRef.current.updateSettings(newSettings);
      }
  };

  const togglePause = useCallback(() => {
    setGameState(prev => {
        if (prev === 'PLAYING') {
            if (gameEngineRef.current) gameEngineRef.current.setPaused(true);
            return 'PAUSED';
        } else if (prev === 'PAUSED') {
            if (gameEngineRef.current) gameEngineRef.current.setPaused(false);
            return 'PLAYING';
        }
        return prev;
    });
  }, []);

  // Keyboard Listeners for Global App State
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
        if (e.code === 'Escape') {
            if (gameState === 'PLAYING' || gameState === 'PAUSED') {
                togglePause();
            }
        }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, togglePause]);

  // Callbacks passed to the game engine to update React state
  const onHUDUpdate = useCallback((state: PlayerState, inVehicle: boolean, speed: number, label: string | null) => {
    setPlayerState({ ...state });
    setIsInVehicle(inVehicle);
    setVehicleSpeed(Math.round(Math.abs(speed * 220))); 
    setInteractLabel(label);
  }, []);

  const onNotification = useCallback((msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 2500);
  }, []);

  const onCollision = useCallback(() => {
    setIsCollisionWarning(true);
    setTimeout(() => setIsCollisionWarning(false), 200);
  }, []);

  const onGameEvent = useCallback((event: 'VICTORY' | 'GAMEOVER', finalState?: PlayerState) => {
    setGameState(event);
    if (finalState) setPlayerState(finalState);
  }, []);

  const onCharacterChange = useCallback((charIndex: number) => {
    setCurrentCharacter(CHARACTERS[charIndex]);
    setNotification(`Vous jouez ${CHARACTERS[charIndex].name}`);
  }, []);

  const onCustomizationOpen = useCallback((data: VehicleCustomizationData) => {
    setCustomizationData(data);
    setIsCustomizing(true);
    if (gameEngineRef.current) gameEngineRef.current.setCustomizationMode(true);
  }, []);

  const onInteraction = useCallback((npc: NPCData | null) => {
    setActiveNPC(npc);
    if (gameEngineRef.current) gameEngineRef.current.setInteractionMode(!!npc);
  }, []);

  const handleCloseCustomization = () => {
    setIsCustomizing(false);
    if (gameEngineRef.current) gameEngineRef.current.setCustomizationMode(false);
  };

  const handleCloseInteraction = () => {
    setActiveNPC(null);
    if (gameEngineRef.current) gameEngineRef.current.setInteractionMode(false);
  };

  const handleNPCAction = (npc: NPCData) => {
    if (gameEngineRef.current) {
      gameEngineRef.current.executeNPCAction(npc);
    }
    handleCloseInteraction();
  };

  const handleVehicleColorChange = (color: number) => {
    setCustomizationData(prev => ({ ...prev, color }));
    if (gameEngineRef.current) {
      gameEngineRef.current.applyCustomization(color, customizationData.wheelType);
    }
  };

  const handleVehicleWheelChange = (wheelType: number) => {
    setCustomizationData(prev => ({ ...prev, wheelType }));
    if (gameEngineRef.current) {
      gameEngineRef.current.applyCustomization(customizationData.color, wheelType);
    }
  };

  useEffect(() => {
    if (canvasRef.current && minimapRef.current && !gameEngineRef.current) {
      const engine = new GameEngine(
        canvasRef.current, 
        minimapRef.current,
        {
          onHUDUpdate,
          onNotification,
          onCollision,
          onGameEvent,
          onCharacterChange,
          onCustomizationOpen,
          onInteraction
        }
      );
      engine.init();
      gameEngineRef.current = engine;
    }

    return () => {
      // Cleanup if needed, though typically this app lives for the session
      if (gameEngineRef.current) {
        gameEngineRef.current.dispose();
      }
    };
  }, [onHUDUpdate, onNotification, onCollision, onGameEvent, onCharacterChange, onCustomizationOpen, onInteraction]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black">
      {/* 3D Canvas */}
      <canvas ref={canvasRef} className="block w-full h-full" />

      {/* Persistent Minimap (rendered but hidden in menu to ensure Ref is populated for GameEngine init) */}
      <div 
        className={`fixed bottom-8 left-8 w-[220px] h-[220px] bg-black/90 border-4 border-green-500 rounded-2xl overflow-hidden shadow-[0_0_30px_rgba(0,255,0,0.5)] z-10 ${gameState === 'PLAYING' ? 'block' : 'hidden'}`}
      >
        <canvas ref={minimapRef} width={220} height={220} className="w-full h-full block" />
      </div>

      {/* UI Layers */}
      {gameState === 'MENU' && (
        <MainMenu 
          selectedChar={selectedCharIndex} 
          onSelectChar={setSelectedCharIndex} 
          onStart={handleStartGame} 
        />
      )}

      {gameState === 'PAUSED' && (
        <PauseMenu 
           onResume={togglePause}
           onQuit={() => window.location.reload()}
           settings={gameSettings}
           onUpdateSettings={handleSettingsUpdate}
        />
      )}

      {(gameState === 'PLAYING' || gameState === 'PAUSED') && playerState && (
        <>
          <HUD 
            playerState={playerState}
            character={currentCharacter}
            notification={notification}
            isCollisionWarning={isCollisionWarning}
            isInVehicle={isInVehicle}
            speed={vehicleSpeed}
            canInteract={interactLabel}
            onPause={togglePause}
          />
          {isCustomizing && (
            <CustomizationMenu 
              onClose={handleCloseCustomization}
              onColorChange={handleVehicleColorChange}
              onWheelChange={handleVehicleWheelChange}
              currentColor={customizationData.color}
            />
          )}
          {activeNPC && (
            <InteractionMenu 
              npc={activeNPC}
              onAction={handleNPCAction}
              onClose={handleCloseInteraction}
            />
          )}
        </>
      )}

      {(gameState === 'VICTORY' || gameState === 'GAMEOVER') && (
        <VictoryScreen 
          type={gameState}
          money={playerState?.money || 0}
          onRestart={handleRestart}
        />
      )}
    </div>
  );
}