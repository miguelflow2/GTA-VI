
export interface Character {
  name: string;
  role: string;
  color: number;
  speed?: number;
  driving?: number;
  shooting?: number;
  strength?: number;
  description?: string; // For AI generation
}

export interface Weapon {
  name: string;
  ammo: number;
  maxAmmo: number;
  damage: number;
  range: number;
}

export type MissionType = 'ELIMINATION' | 'DELIVERY' | 'HEIST' | 'ASSASSINATION' | 'CHASE' | 'TIMED_DELIVERY';

export interface Mission {
  id: number;
  type: MissionType;
  title: string;
  description: string;
  targetCount?: number; // For elimination
  targetVehicleColor?: number; // For heist
  timeLimit?: number; // Seconds for timed missions
}

export type NPCType = 'QUEST' | 'VENDOR' | 'MEDIC' | 'MECHANIC' | 'BRIBE' | 'BLACK_MARKET' | 'INFORMANT' | 'GAMBLER' | 'TRAINER' | 'TAXI';

export interface NPCData {
  id: number;
  type: NPCType;
  name: string;
  dialogue: string;
  serviceLabel: string;
  cost: number;
  position: [number, number, number];
  color: number;
}

export type WeatherType = 'SUN' | 'RAIN' | 'FOG' | 'STORM';

export interface SkillStats {
  driving: number;
  shooting: number;
  strength: number;
  stamina: number;
  flying: number;
  stealth: number;
}

export interface PlayerState {
  health: number;
  maxHealth: number;
  armor: number;
  maxArmor: number;
  stamina: number;
  maxStamina: number;
  currentWeapon: number;
  wantedLevel: number;
  kills: number;
  money: number;
  isJumping: boolean;
  velocityY: number;
  // Mission State
  activeMission: Mission | null;
  missionProgress: string; // Text description like "0/5 Enemies" or "Go to extraction"
  missionCompleted: boolean;
  missionTimeLeft?: number; // Seconds remaining
  // New Systems
  skills: SkillStats;
  currentWeather: WeatherType;
}

export interface GameConfig {
  player: {
    walkSpeed: number;
    runSpeed: number;
    rotSpeed: number;
    jumpHeight: number;
    gravity: number;
  };
  vehicle: {
    maxSpeed: number;
    acceleration: number;
    deceleration: number;
    friction: number;
    turnSpeed: number;
    driftFactor: number;
  };
  combat: {
    bulletSpeed: number;
    bulletRange: number;
    fireRate: number;
    hitDetectionRadius: number;
  };
  world: {
    size: number;
    renderDistance: number;
  };
  ai: {
    enemySpeed: number;
    citizenSpeed: number;
    vehicleSpeed: number;
    detectionRange: number;
    attackRange: number;
  };
}

export interface GameSettings {
  musicVolume: number;
  sfxVolume: number;
  sensitivity: number;
  renderDistance: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface VehicleCustomizationData {
  color: number;
  wheelType: number;
}

export interface GameCallbacks {
  onHUDUpdate: (state: PlayerState, inVehicle: boolean, speed: number, interactLabel: string | null) => void;
  onNotification: (msg: string) => void;
  onCollision: () => void;
  onGameEvent: (event: 'VICTORY' | 'GAMEOVER', finalState?: PlayerState) => void;
  onCharacterChange: (charIndex: number) => void;
  onCustomizationOpen: (data: VehicleCustomizationData) => void;
  onInteraction: (npc: NPCData | null) => void;
}
