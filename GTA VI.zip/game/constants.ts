
import { GameConfig, Character, Weapon, Mission, NPCData, WeatherType } from '../types';

export const CONFIG: GameConfig = {
  player: {
    walkSpeed: 0.45,
    runSpeed: 1.1,
    rotSpeed: 0.15,
    jumpHeight: 0.7,
    gravity: 0.04
  },
  vehicle: {
    maxSpeed: 6.0,   // Vitesse augmentée pour les autoroutes de Leonida
    acceleration: 0.09,
    deceleration: 0.04,
    friction: 0.99,
    turnSpeed: 0.075,
    driftFactor: 0.94
  },
  combat: {
    bulletSpeed: 8.0,
    bulletRange: 400,
    fireRate: 90,
    hitDetectionRadius: 4.5
  },
  world: {
    size: 6000, // Monde agrandi pour accueillir les Keys et Grassrivers
    renderDistance: 1200 // Distance de vue augmentée pour les panoramas
  },
  ai: {
    enemySpeed: 0.4,
    citizenSpeed: 0.25,
    vehicleSpeed: 1.6,
    detectionRange: 100,
    attackRange: 130
  }
};

export const WEATHER_CONFIG: Record<WeatherType, { color: number, fogDensity: number, frictionMod: number }> = {
  SUN: { color: 0xffaaee, fogDensity: 0.0008, frictionMod: 1.0 },
  RAIN: { color: 0x222233, fogDensity: 0.0025, frictionMod: 0.96 }, // Slippery
  FOG: { color: 0x888899, fogDensity: 0.006, frictionMod: 1.0 },
  STORM: { color: 0x110022, fogDensity: 0.0035, frictionMod: 0.94 } // Very slippery
};

export const CHARACTERS: Character[] = [
  { 
    name: 'LUCIA', 
    role: 'Infiltration & Stratégie', 
    color: 0xe91e63, 
    speed: 1.2, 
    shooting: 1.1, 
    strength: 0.9,
    description: "Grand Theft Auto VI loading screen art style, digital painting, masterpiece. Portrait of Lucia, a fierce latina woman in her late 20s. Wearing a crop top and tactical pants. She has messy bun hair, sweat on skin, holding a pistol. Background is a vibrant Vice City sunset with palm trees and neon pink lighting. High contrast, sharp details, cel-shaded realism."
  }, 
  { 
    name: 'JASON', 
    role: 'Force & Pilotage', 
    color: 0x00bcd4, 
    speed: 1.0, 
    driving: 1.5, 
    strength: 1.4,
    description: "Grand Theft Auto VI loading screen art style, digital painting, masterpiece. Portrait of Jason, a tough caucasian man in his early 30s. Wearing a backwards baseball cap and a dirty white tank top. Stubble beard, gritty texture, looking intense. Background is the Florida Keys swamps with an airboat and green water. High contrast, sharp details, cel-shaded realism." 
  }
];

// Damage increased by ~15% across the board
export const INITIAL_WEAPONS: Weapon[] = [
  { name: 'POING', ammo: Infinity, maxAmmo: Infinity, damage: 35, range: 4 },
  { name: 'PISTOLET 9mm', ammo: 60, maxAmmo: 180, damage: 46, range: 120 },
  { name: 'FUSIL D\'ASSAUT', ammo: 90, maxAmmo: 270, damage: 64, range: 200 },
  { name: 'POMPE TACTIQUE', ammo: 16, maxAmmo: 64, damage: 127, range: 35 },
  { name: 'SMG COMPACT', ammo: 120, maxAmmo: 360, damage: 33, range: 90 }
];

export const MISSIONS: Mission[] = [
  {
    id: 1,
    type: 'ELIMINATION',
    title: 'SORTIE DE PRISON',
    description: 'Lucia est dehors. Réglez vos comptes avec le gang qui vous a balancé à Port Gellhorn.',
    targetCount: 5
  },
  {
    id: 2,
    type: 'HEIST',
    title: 'BRAQUAGE DE L\'EPICERIE',
    description: 'Un coup "facile" à Vice City pour se refaire. Volez la voiture de fuite (Jaune).',
    targetVehicleColor: 0xffff00
  },
  {
    id: 3,
    type: 'CHASE',
    title: 'FUITE VERS LES KEYS',
    description: 'La police est partout. Interceptez le contact dans les Keys avant qu\'il ne parle.',
  },
  {
    id: 4,
    type: 'DELIVERY',
    title: 'MARÉCAGES DE GRASSRIVERS',
    description: 'Récupérez la cargaison cachée dans les Everglades au milieu des alligators.',
  },
  {
    id: 5,
    type: 'ASSASSINATION',
    title: 'LE COMPLOT',
    description: 'Le sénateur corrompu fait une fête à Ambrosia. Éliminez la cible VIP.',
  },
  {
    id: 6,
    type: 'TIMED_DELIVERY',
    title: 'LEONIDA RUSH',
    description: 'Traversez tout l\'état du Nord au Sud en moins de 60 secondes !',
    timeLimit: 60
  }
];

export const INTERACTIVE_NPCS: NPCData[] = [
  {
    id: 1,
    type: 'QUEST',
    name: 'CONTACT SOCIAL',
    dialogue: "T'as vu ça sur LifeInvader ? On peut se faire un max de likes... et de fric.",
    serviceLabel: "Lancer Mission Virale",
    cost: 0,
    position: [100, 0, 100],
    color: 0xff00ff // Magenta néon
  },
  {
    id: 2,
    type: 'VENDOR',
    name: 'PAWN & GUN',
    dialogue: "C'est la Floride ici, tout le monde est armé.",
    serviceLabel: "Recharger Armes",
    cost: 400,
    position: [-80, 0, -80],
    color: 0x4caf50
  },
  {
    id: 3,
    type: 'TRAINER',
    name: 'MUSCLE BEACH GYM',
    dialogue: "GONFLETTE ! Pousse de la fonte pour devenir une bête !",
    serviceLabel: "Séance Muscu (Boost Force)",
    cost: 150,
    position: [300, 0, -300], // Zone Vice City Beach
    color: 0xff8c00
  },
  {
    id: 4,
    type: 'MECHANIC',
    name: 'SPRAY & PRAY',
    dialogue: "Nouvelle peinture, nouvelle vie. Les flics n'y verront que du feu.",
    serviceLabel: "Réparer & Maquiller",
    cost: 250,
    position: [-120, 0, 50],
    color: 0x2196f3
  },
  {
    id: 5,
    type: 'GAMBLER',
    name: 'PARI CLANDESTIN',
    dialogue: "Combat d'alligators ce soir. Tu mises ?",
    serviceLabel: "Miser $2000",
    cost: 2000,
    position: [-500, 0, 500], // Zone Grassrivers
    color: 0x5d4037
  },
  {
    id: 6,
    type: 'INFORMANT',
    name: 'HACKER LIFEINVADER',
    dialogue: "Je peux supprimer ton casier judiciaire des serveurs.",
    serviceLabel: "Effacer Indice",
    cost: 1500,
    position: [10, 0, 180],
    color: 0x9c27b0
  },
  {
    id: 7,
    type: 'BLACK_MARKET',
    name: 'CONTREBANDIER DES KEYS',
    dialogue: "J'ai du matos lourd qui vient direct du sud.",
    serviceLabel: "Minigun + Gilet",
    cost: 5000,
    position: [0, 0, 1200], // Zone Keys
    color: 0x222222
  },
  {
    id: 8,
    type: 'MEDIC',
    name: 'CLINIQUE PRIVÉE',
    dialogue: "Pas de questions, pas de rapport de police.",
    serviceLabel: "Soins d'urgence",
    cost: 500,
    position: [50, 0, -150],
    color: 0xffffff
  },
  {
    id: 9,
    type: 'QUEST', // Utilisation type QUEST pour l'activité
    name: 'CLUB DE PÊCHE',
    dialogue: "Rien de tel que le calme avant la tempête.",
    serviceLabel: "Louer Bateau",
    cost: 300,
    position: [800, 0, 800], // Port
    color: 0x00bcd4
  },
  {
    id: 10,
    type: 'TAXI',
    name: 'VICE CAB',
    dialogue: "Où tu veux, quand tu veux. Sauf dans les marais.",
    serviceLabel: "Voyage Rapide",
    cost: 100,
    position: [200, 0, 50],
    color: 0xffff00
  }
];
