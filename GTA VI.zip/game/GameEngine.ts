
import * as THREE from 'three';
import { CONFIG, CHARACTERS, INITIAL_WEAPONS, MISSIONS, INTERACTIVE_NPCS, WEATHER_CONFIG } from './constants';
import { PlayerState, GameCallbacks, Weapon, Mission, NPCData, GameSettings, WeatherType } from '../types';

// Biome Definitions
type Biome = 'VICE_CITY' | 'GRASSRIVERS' | 'KEYS' | 'AMBROSIA';

// AI States
type CitizenState = 'WANDER' | 'FLEE' | 'COWER' | 'CALL_POLICE';

// Lightweight Collision Interface to replace full Meshes in grid
interface CollisionObject {
  box: THREE.Box3;
}

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private minimapCanvas: HTMLCanvasElement;
  private callbacks: GameCallbacks;

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private audioListener!: THREE.AudioListener;
  
  private player!: THREE.Group;
  private inVehicle: THREE.Object3D | null = null;
  private nearbyVehicle: THREE.Object3D | null = null;
  private nearbyNPC: THREE.Mesh | null = null;
  
  // Spatial Partitioning for Static Objects (Lightweight)
  private spatialGrid: Map<string, CollisionObject[]> = new Map();
  private cellSize = 300; 

  // Object Pools & Caches
  private boxGeo = new THREE.BoxGeometry(1, 1, 1);
  private roadGeo = new THREE.PlaneGeometry(CONFIG.world.size, 30);
  private materialCache: Map<string, THREE.Material> = new Map();
  
  // Reusable temporaries to avoid GC
  private dummy = new THREE.Object3D();
  private tempMatrix = new THREE.Matrix4();
  private tempBox = new THREE.Box3();
  private tempVec = new THREE.Vector3();
  private raycaster = new THREE.Raycaster(); // General use

  // Instancing Arrays
  private instanceData: Map<string, THREE.Matrix4[]> = new Map();

  private vehicles: THREE.Object3D[] = [];
  private enemies: THREE.Mesh[] = [];
  private citizens: THREE.Mesh[] = [];
  private npcs: THREE.Mesh[] = [];
  private bullets: THREE.Mesh[] = [];
  
  // Particle System (Pooled)
  private particles: THREE.Mesh[] = [];
  private particlePool: THREE.Mesh[] = [];
  private maxParticles = 200;

  // Weather System
  private weatherTimer: number = 0;
  private rainSystem: THREE.InstancedMesh | null = null;
  private lightningLight: THREE.PointLight | null = null;

  private missionMarkers: THREE.Group = new THREE.Group();
  
  // Character Parts for animation
  private torso!: THREE.Mesh;
  private head!: THREE.Mesh;
  private leftLeg!: THREE.Mesh;
  private rightLeg!: THREE.Mesh;
  private leftArm!: THREE.Mesh;
  private rightArm!: THREE.Mesh;

  private isStarted = false;
  private isPaused = false;
  private isCustomizing = false;
  private isInteracting = false;
  private keys: { [key: string]: boolean } = {};
  private lastShotTime = 0;
  private isWalking = false; 
  private currentCharIndex = 0;
  private animationFrameId: number | null = null;
  private currentSettings: GameSettings = { musicVolume: 0.5, sfxVolume: 0.5, sensitivity: 1.0, renderDistance: 'MEDIUM' };

  private forwardRaycaster = new THREE.Raycaster();

  // Mission State
  private currentMissionIndex = 0;
  private missionObjKills = 0;
  private missionObjectivePos: THREE.Vector3 | null = null;
  private missionDropoffPos: THREE.Vector3 | null = null;
  private missionState = 0; 
  private missionTargetVehicle: THREE.Object3D | null = null;
  private missionTargetEnemy: THREE.Mesh | null = null;
  private missionEndTime: number = 0;

  // Mutable game state
  public state: PlayerState = {
    health: 100,
    maxHealth: 100,
    armor: 100,
    maxArmor: 100,
    stamina: 100,
    maxStamina: 100,
    currentWeapon: 1,
    wantedLevel: 0,
    kills: 0,
    money: 250, 
    isJumping: false,
    velocityY: 0,
    activeMission: null,
    missionProgress: '',
    missionCompleted: false,
    missionTimeLeft: 0,
    currentWeather: 'SUN',
    skills: {
        driving: 10,
        shooting: 10,
        strength: 10,
        stamina: 10,
        flying: 0,
        stealth: 0
    }
  };

  public weapons: Weapon[] = JSON.parse(JSON.stringify(INITIAL_WEAPONS));

  constructor(
    canvas: HTMLCanvasElement, 
    minimapCanvas: HTMLCanvasElement, 
    callbacks: GameCallbacks
  ) {
    this.canvas = canvas;
    this.minimapCanvas = minimapCanvas;
    this.callbacks = callbacks;

    this.onKeyDown = this.onKeyDown.bind(this);
    this.onKeyUp = this.onKeyUp.bind(this);
    this.onResize = this.onResize.bind(this);
    this.animate = this.animate.bind(this);
  }

  public init() {
    this.scene = new THREE.Scene();
    
    // Audio Init
    this.audioListener = new THREE.AudioListener();
    this.camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 4000);
    this.camera.add(this.audioListener);

    // Initial Weather Setup
    this.setWeather('SUN');

    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true, powerPreference: "high-performance" });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;

    this.initParticlePool();
    this.setupLights();
    this.createWorld();
    
    // Create Player FIRST before attaching rain system
    this.createPlayer(); 
    this.initRainSystem();

    this.spawnVehicles(100); 
    this.spawnParkedVehicles(60); 
    this.spawnEnemies(25);
    this.spawnCitizens(100);
    this.spawnNPCs();

    this.scene.add(this.missionMarkers);

    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('resize', this.onResize);

    this.animate();
    this.playSound('AMBIANCE');
  }

  public setPaused(paused: boolean) {
    this.isPaused = paused;
  }

  public updateSettings(settings: GameSettings) {
    this.currentSettings = settings;
    this.audioListener.setMasterVolume(settings.sfxVolume);
  }

  // --- AUDIO SYSTEM ---
  private playSound(type: 'SHOOT' | 'HIT' | 'EXPLOSION' | 'ENGINE' | 'AMBIANCE' | 'UI' | 'POLICE' | 'THUNDER') {
    if (!this.audioListener) return;
    const sound = new THREE.Audio(this.audioListener);
    const context = this.audioListener.context;
    
    const oscillator = context.createOscillator();
    const gainNode = context.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(sound.getOutput());

    const now = context.currentTime;

    switch (type) {
      case 'SHOOT':
        oscillator.type = 'sawtooth';
        oscillator.frequency.setValueAtTime(600, now);
        oscillator.frequency.exponentialRampToValueAtTime(100, now + 0.1);
        gainNode.gain.setValueAtTime(0.5, now);
        gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
        oscillator.start(now);
        oscillator.stop(now + 0.1);
        break;
      case 'EXPLOSION':
      case 'THUNDER':
        oscillator.type = 'sawtooth'; // Rougher sound for thunder
        oscillator.frequency.setValueAtTime(50, now);
        oscillator.frequency.exponentialRampToValueAtTime(10, now + 1.0);
        gainNode.gain.setValueAtTime(1.0, now);
        gainNode.gain.exponentialRampToValueAtTime(0.01, now + 1.0);
        oscillator.start(now);
        oscillator.stop(now + 1.0);
        break;
      case 'HIT':
        oscillator.type = 'triangle';
        oscillator.frequency.setValueAtTime(200, now);
        gainNode.gain.setValueAtTime(0.3, now);
        gainNode.gain.linearRampToValueAtTime(0, now + 0.05);
        oscillator.start(now);
        oscillator.stop(now + 0.05);
        break;
      case 'ENGINE':
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(100, now);
        oscillator.frequency.linearRampToValueAtTime(300, now + 0.2);
        gainNode.gain.setValueAtTime(0.2, now);
        gainNode.gain.linearRampToValueAtTime(0, now + 0.2);
        oscillator.start(now);
        oscillator.stop(now + 0.2);
        break;
      case 'UI':
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(800, now);
        gainNode.gain.setValueAtTime(0.1, now);
        gainNode.gain.linearRampToValueAtTime(0, now + 0.1);
        oscillator.start(now);
        oscillator.stop(now + 0.1);
        break;
      case 'POLICE':
        oscillator.type = 'square';
        oscillator.frequency.setValueAtTime(800, now);
        oscillator.frequency.linearRampToValueAtTime(600, now + 0.5);
        gainNode.gain.setValueAtTime(0.2, now);
        gainNode.gain.linearRampToValueAtTime(0, now + 0.5);
        oscillator.start(now);
        oscillator.stop(now + 0.5);
        break;
    }
  }

  // --- DYNAMIC WEATHER SYSTEM ---
  private setWeather(type: WeatherType) {
    this.state.currentWeather = type;
    const config = WEATHER_CONFIG[type];
    
    // Smooth transition (Visuals)
    this.scene.background = new THREE.Color(config.color);
    this.scene.fog = new THREE.FogExp2(config.color, config.fogDensity);
    
    if (this.rainSystem) {
        this.rainSystem.visible = (type === 'RAIN' || type === 'STORM');
    }

    if (type === 'STORM' && !this.lightningLight) {
        this.lightningLight = new THREE.PointLight(0xffffff, 0, 10000);
        this.scene.add(this.lightningLight);
    }

    let msg = "";
    if (type === 'SUN') msg = "Météo: Grand Soleil sur Leonida";
    if (type === 'RAIN') msg = "Météo: Pluies Tropicales (Route Glissante)";
    if (type === 'FOG') msg = "Météo: Brouillard (Visibilité Réduite)";
    if (type === 'STORM') msg = "Météo: Tempête Violent !";
    
    this.callbacks.onNotification(msg);
  }

  private initRainSystem() {
     const count = 8000;
     const geo = new THREE.BoxGeometry(0.05, 1.5, 0.05);
     const mat = new THREE.MeshBasicMaterial({color: 0xaaaaaa, transparent: true, opacity: 0.5});
     this.rainSystem = new THREE.InstancedMesh(geo, mat, count);
     this.rainSystem.frustumCulled = false;
     
     const dummy = new THREE.Object3D();
     for(let i=0; i<count; i++) {
        dummy.position.set(
            (Math.random() - 0.5) * 300,
            Math.random() * 150,
            (Math.random() - 0.5) * 300
        );
        dummy.updateMatrix();
        this.rainSystem.setMatrixAt(i, dummy.matrix);
     }
     this.rainSystem.visible = false;
     if (this.player) {
        this.player.add(this.rainSystem); // Attach to player so it follows
     }
  }

  private updateWeather() {
     this.weatherTimer++;
     // Change weather roughly every 2 minutes (7200 frames @ 60fps)
     if (this.weatherTimer > 7200) { 
         this.weatherTimer = 0;
         const r = Math.random();
         if (r < 0.5) this.setWeather('SUN');
         else if (r < 0.7) this.setWeather('RAIN');
         else if (r < 0.9) this.setWeather('FOG');
         else this.setWeather('STORM');
     }

     // Rain Animation
     if ((this.state.currentWeather === 'RAIN' || this.state.currentWeather === 'STORM') && this.rainSystem) {
        this.rainSystem.position.y -= 0.8;
        if (this.rainSystem.position.y < -30) this.rainSystem.position.y = 0;
     }

     // Lightning
     if (this.state.currentWeather === 'STORM' && this.lightningLight) {
         if (Math.random() < 0.01) { // 1% chance per frame
             this.lightningLight.intensity = 5 + Math.random() * 5;
             this.scene.background = new THREE.Color(0x333344); // Flash sky
             this.playSound('THUNDER');
             setTimeout(() => {
                 if (this.lightningLight) this.lightningLight.intensity = 0;
                 if (this.scene) this.scene.background = new THREE.Color(WEATHER_CONFIG.STORM.color);
             }, 100);
         }
     }
  }

  // --- VEHICLE DEFORMATION ---
  private deformMesh(mesh: THREE.Mesh, point: THREE.Vector3, force: number) {
      if (!mesh.geometry) return;
      const positions = mesh.geometry.attributes.position;
      const v = new THREE.Vector3();
      let damaged = false;

      for (let i = 0; i < positions.count; i++) {
          v.fromBufferAttribute(positions, i);
          // Transform local vertex to world to check distance
          const worldV = v.clone().applyMatrix4(mesh.matrixWorld);
          const dist = worldV.distanceTo(point);
          
          if (dist < force * 2) {
              // Push vertex inward randomly
              const deform = new THREE.Vector3(
                  (Math.random() - 0.5) * force * 0.5,
                  (Math.random() - 0.5) * force * 0.5,
                  (Math.random() - 0.5) * force * 0.5
              );
              v.add(deform);
              positions.setXYZ(i, v.x, v.y, v.z);
              damaged = true;
          }
      }

      if (damaged) {
          positions.needsUpdate = true;
          mesh.geometry.computeVertexNormals();
          
          // Visual change: Darken color or look rougher
          if (mesh.material instanceof THREE.MeshPhongMaterial) {
              mesh.material.color.lerp(new THREE.Color(0x333333), 0.2);
          }
      }
  }

  private initParticlePool() {
    const particleGeo = new THREE.BoxGeometry(1, 1, 1);
    const particleMat = new THREE.MeshBasicMaterial({ color: 0xffff00, transparent: true });
    
    for (let i = 0; i < this.maxParticles; i++) {
        const mesh = new THREE.Mesh(particleGeo, particleMat.clone());
        mesh.visible = false;
        mesh.frustumCulled = false; // Optimization for small particles
        this.scene.add(mesh);
        this.particlePool.push(mesh);
    }
  }

  private setupLights() {
    const ambientLight = new THREE.AmbientLight(0xffccaa, 0.5); 
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffddaa, 1.2); 
    dirLight.position.set(500, 800, 500);
    dirLight.castShadow = true;
    
    // Optimized Shadow Map Settings
    dirLight.shadow.mapSize.width = 2048; 
    dirLight.shadow.mapSize.height = 2048;
    
    const d = 1500; 
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    dirLight.shadow.camera.far = 3000;
    dirLight.shadow.bias = -0.0002;
    this.scene.add(dirLight);
    
    const hemiLight = new THREE.HemisphereLight(0x444488, 0x442200, 0.3);
    this.scene.add(hemiLight);
  }

  private getBiome(x: number, z: number): Biome {
    if (z > 800) return 'KEYS'; 
    if (x < -600) return 'GRASSRIVERS'; 
    if (z < -800) return 'AMBROSIA'; 
    return 'VICE_CITY'; 
  }

  private getMaterial(key: string, createFn: () => THREE.Material): THREE.Material {
    if (!this.materialCache.has(key)) {
      this.materialCache.set(key, createFn());
    }
    return this.materialCache.get(key)!;
  }

  private addInstance(key: string, matrix: THREE.Matrix4) {
      if (!this.instanceData.has(key)) {
          this.instanceData.set(key, []);
      }
      this.instanceData.get(key)!.push(matrix.clone());
  }

  private createWorld() {
    // 1. Water
    const waterGeo = new THREE.PlaneGeometry(CONFIG.world.size * 1.5, CONFIG.world.size * 1.5);
    const waterMat = new THREE.MeshPhongMaterial({ 
      color: 0x006699, 
      specular: 0xffffff, 
      shininess: 100, 
      transparent: true,
      opacity: 0.9 
    });
    const water = new THREE.Mesh(waterGeo, waterMat);
    water.rotation.x = -Math.PI / 2;
    water.position.y = -2;
    this.scene.add(water);

    // 2. Ground
    const groundGeo = new THREE.PlaneGeometry(CONFIG.world.size, CONFIG.world.size, 64, 64); // Reduced segments
    const groundMat = new THREE.MeshLambertMaterial({ color: 0x3a4a3a }); 
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.scene.add(ground);

    // 3. Collect Data for Static World
    this.collectRoadData();
    // 4. Build Instanced Meshes
    this.buildWorldMeshes();
    
    // 5. Dynamic Vegetation
    this.createVegetation();
  }

  // ... (collectRoadData, collectBuildingData, buildWorldMeshes, fillInstancedMesh, createVegetation methods remain unchanged)
  private collectRoadData() {
    const range = 18; 
    const step = 150;

    for (let i = -range; i <= range; i++) {
      const pos = i * step;

      // Road Surfaces
      this.dummy.position.set(0, 0.1, pos);
      this.dummy.rotation.set(-Math.PI / 2, 0, 0);
      this.dummy.scale.set(1, 1, 1);
      this.dummy.updateMatrix();
      this.addInstance('ROAD', this.dummy.matrix);

      this.dummy.position.set(pos, 0.1, 0);
      this.dummy.rotation.set(-Math.PI / 2, 0, -Math.PI / 2);
      this.dummy.updateMatrix();
      this.addInstance('ROAD', this.dummy.matrix);

      // Lines
      if (i % 2 === 0) {
        for (let j = -30; j <= 30; j++) {
          this.dummy.rotation.set(-Math.PI / 2, 0, 0);
          this.dummy.position.set(pos, 0.12, j * 15);
          this.dummy.scale.set(1, 1, 1); 
          this.dummy.updateMatrix();
          this.addInstance('LINE', this.dummy.matrix);
          
          this.dummy.rotation.set(-Math.PI / 2, 0, -Math.PI / 2);
          this.dummy.position.set(j * 15, 0.12, pos);
          this.dummy.updateMatrix();
          this.addInstance('LINE', this.dummy.matrix);
        }
      }

      // Buildings
      for (let j = -range; j <= range; j++) {
        if (Math.abs(i) % 2 === 0 || Math.abs(j) % 2 === 0) continue;

        const bx = i * 75;
        const bz = j * 75;
        const biome = this.getBiome(bx, bz);

        let spawn = false;
        if (biome === 'VICE_CITY') spawn = Math.random() > 0.1;
        else if (biome === 'AMBROSIA') spawn = Math.random() > 0.5;
        else if (biome === 'KEYS') spawn = Math.random() > 0.7;
        else spawn = Math.random() > 0.9;
        
        if (spawn) this.collectBuildingData(bx, bz, biome);
      }
    }
  }

  private collectBuildingData(x: number, z: number, biome: Biome) {
    let w, h, d, matKey;
    
    if (biome === 'VICE_CITY') {
       h = 100 + Math.random() * 300;
       w = 40 + Math.random() * 30;
       d = 40 + Math.random() * 30;
       const colors = ['#ff00ff', '#00ffff', '#ffffff', '#88ccff', '#ffaa00'];
       const colorKey = colors[Math.floor(Math.random() * colors.length)];
       matKey = `VC_${colorKey}`;
    } else if (biome === 'GRASSRIVERS') {
       h = 15 + Math.random() * 10;
       w = 30 + Math.random() * 10;
       d = 30 + Math.random() * 10;
       matKey = 'SHACK';
    } else if (biome === 'KEYS') {
       h = 25 + Math.random() * 20;
       w = 50 + Math.random() * 20;
       d = 50 + Math.random() * 20;
       matKey = 'VILLA';
    } else {
       h = 30 + Math.random() * 40;
       w = 50 + Math.random() * 40;
       d = 50 + Math.random() * 40;
       matKey = 'IND';
    }

    // Body Matrix
    this.dummy.position.set(x, h / 2, z);
    this.dummy.rotation.set(0, 0, 0);
    this.dummy.scale.set(w, h, d);
    this.dummy.updateMatrix();
    this.addInstance(matKey, this.dummy.matrix);

    // Roof Matrix
    this.dummy.position.set(x, h + 0.5, z);
    this.dummy.scale.set(w + 1, 1, d + 1);
    this.dummy.updateMatrix();
    this.addInstance('ROOF', this.dummy.matrix);

    // Neon (Vice City only)
    if (biome === 'VICE_CITY' && Math.random() > 0.5) {
       this.dummy.position.set(x, h - 5, z);
       this.dummy.scale.set(w + 2, 1, d + 2);
       this.dummy.updateMatrix();
       this.addInstance('NEON', this.dummy.matrix);
    }

    // Collision Data (Lightweight)
    const box = new THREE.Box3();
    box.setFromCenterAndSize(new THREE.Vector3(x, h/2, z), new THREE.Vector3(w, h, d));
    
    const key = `${Math.floor(x / this.cellSize)},${Math.floor(z / this.cellSize)}`;
    if (!this.spatialGrid.has(key)) {
      this.spatialGrid.set(key, []);
    }
    this.spatialGrid.get(key)!.push({ box });
  }

  private buildWorldMeshes() {
      // 1. Roads
      if (this.instanceData.has('ROAD')) {
          const matrices = this.instanceData.get('ROAD')!;
          const mesh = new THREE.InstancedMesh(this.roadGeo, new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.8 }), matrices.length);
          mesh.receiveShadow = true;
          this.fillInstancedMesh(mesh, matrices);
          this.scene.add(mesh);
      }
      // 2. Lines
      if (this.instanceData.has('LINE')) {
          const matrices = this.instanceData.get('LINE')!;
          const mesh = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.5, 6), new THREE.MeshBasicMaterial({ color: 0xffffff }), matrices.length);
          // Lines don't receive/cast shadows usually to save perf, or enable if needed
          this.fillInstancedMesh(mesh, matrices);
          this.scene.add(mesh);
      }
      
      // 3. Buildings
      this.instanceData.forEach((matrices, key) => {
          if (key === 'ROAD' || key === 'LINE') return; // Handled above

          let mat: THREE.Material;
          if (key.startsWith('VC_')) {
              const color = key.replace('VC_', '');
              mat = this.getMaterial(key, () => new THREE.MeshPhysicalMaterial({ color, metalness: 0.8, roughness: 0.2, clearcoat: 1.0 }));
          } else if (key === 'SHACK') {
              mat = this.getMaterial(key, () => new THREE.MeshLambertMaterial({ color: 0x5d4037 }));
          } else if (key === 'VILLA') {
              mat = this.getMaterial(key, () => new THREE.MeshStandardMaterial({ color: 0xfffff0 }));
          } else if (key === 'IND') {
              mat = this.getMaterial(key, () => new THREE.MeshLambertMaterial({ color: 0x888888 }));
          } else if (key === 'ROOF') {
              mat = this.getMaterial(key, () => new THREE.MeshLambertMaterial({ color: 0x222222 }));
          } else if (key === 'NEON') {
              mat = this.getMaterial(key, () => new THREE.MeshBasicMaterial({ color: 0xff00ff, toneMapped: false }));
          } else {
              mat = new THREE.MeshBasicMaterial({ color: 0xffffff }); // Fallback
          }

          const mesh = new THREE.InstancedMesh(this.boxGeo, mat, matrices.length);
          mesh.castShadow = true;
          mesh.receiveShadow = true;
          this.fillInstancedMesh(mesh, matrices);
          this.scene.add(mesh);
      });
  }

  private fillInstancedMesh(mesh: THREE.InstancedMesh, matrices: THREE.Matrix4[]) {
      for (let i = 0; i < matrices.length; i++) {
          mesh.setMatrixAt(i, matrices[i]);
      }
      mesh.instanceMatrix.needsUpdate = true;
  }

  private createVegetation() {
    const treeCount = 1000; 
    const trunkGeo = new THREE.CylinderGeometry(0.5, 0.8, 6, 8);
    const foliageGeo = new THREE.DodecahedronGeometry(3.5); 
    const trunkMat = new THREE.MeshLambertMaterial({ color: 0x8b4513 });
    const foliageMat = new THREE.MeshLambertMaterial({ color: 0x228b22 });

    const trunkMesh = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
    const foliageMesh = new THREE.InstancedMesh(foliageGeo, foliageMat, treeCount);
    
    trunkMesh.castShadow = true;
    trunkMesh.receiveShadow = true;
    foliageMesh.castShadow = true;
    foliageMesh.receiveShadow = true;

    let index = 0;
    for (let i = 0; i < treeCount; i++) {
        const x = (Math.random() - 0.5) * CONFIG.world.size;
        const z = (Math.random() - 0.5) * CONFIG.world.size;
        const biome = this.getBiome(x, z);

        let shouldSpawn = false;
        if (biome === 'GRASSRIVERS') shouldSpawn = Math.random() > 0.2; 
        if (biome === 'KEYS') shouldSpawn = Math.random() > 0.6; 
        if (biome === 'VICE_CITY') shouldSpawn = Math.random() > 0.9; 
        if (biome === 'AMBROSIA') shouldSpawn = Math.random() > 0.7;

        if (!shouldSpawn || this.isOnRoad(new THREE.Vector3(x, 0, z))) continue;

        const scaleY = biome === 'VICE_CITY' || biome === 'KEYS' ? 1.5 : 1; 

        this.dummy.position.set(x, 3 * scaleY, z);
        this.dummy.rotation.set(0, Math.random() * Math.PI, 0);
        this.dummy.scale.set(1, scaleY, 1);
        this.dummy.updateMatrix();
        trunkMesh.setMatrixAt(index, this.dummy.matrix);

        this.dummy.position.set(x, 6 * scaleY, z);
        this.dummy.scale.set(1, 1, 1);
        this.dummy.updateMatrix();
        foliageMesh.setMatrixAt(index, this.dummy.matrix);
        
        index++;
    }
    trunkMesh.count = index;
    foliageMesh.count = index;
    
    this.scene.add(trunkMesh);
    this.scene.add(foliageMesh);

    // Street Lamps
    const lampCount = 300; 
    const poleGeo = new THREE.CylinderGeometry(0.1, 0.1, 10, 8);
    const lightGeo = new THREE.BoxGeometry(2, 0.5, 1);
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.5 });
    const lightMat = new THREE.MeshBasicMaterial({ color: 0xffaa00 });

    const poleMesh = new THREE.InstancedMesh(poleGeo, poleMat, lampCount);
    const lightMesh = new THREE.InstancedMesh(lightGeo, lightMat, lampCount);
    
    poleMesh.castShadow = true;

    let lIndex = 0;
    for (let i = -18; i <= 18; i+=2) {
        for (let j = -18; j <= 18; j+=2) {
             const x = i * 150 + 20;
             const z = j * 150 + 20;
             const biome = this.getBiome(x, z);
             
             if (biome === 'GRASSRIVERS') continue; 
             
             if (lIndex < lampCount) {
                this.dummy.position.set(x, 5, z);
                this.dummy.rotation.set(0, 0, 0);
                this.dummy.scale.set(1, 1, 1);
                this.dummy.updateMatrix();
                poleMesh.setMatrixAt(lIndex, this.dummy.matrix);

                this.dummy.position.set(x, 10, z);
                this.dummy.updateMatrix();
                lightMesh.setMatrixAt(lIndex, this.dummy.matrix);
                lIndex++;
             }
        }
    }
    poleMesh.count = lIndex;
    lightMesh.count = lIndex;
    this.scene.add(poleMesh);
    this.scene.add(lightMesh);
  }

  // --- MISSING METHODS IMPLEMENTATION ---

  private onResize() {
    if (!this.camera || !this.renderer) return;
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  private isOnRoad(pos: THREE.Vector3): boolean {
    const roadStep = 150;
    const roadWidth = 25;
    const distX = Math.abs(pos.x - Math.round(pos.x / roadStep) * roadStep);
    const distZ = Math.abs(pos.z - Math.round(pos.z / roadStep) * roadStep);
    return distX < roadWidth || distZ < roadWidth;
  }

  private createPlayer() {
    if (this.player) this.scene.remove(this.player);
    this.player = new THREE.Group();
    this.player.scale.set(1, 1, 1); 

    const char = CHARACTERS[this.currentCharIndex];
    const skinMat = new THREE.MeshPhongMaterial({ color: 0xffdbac });
    const clothesMat = new THREE.MeshPhongMaterial({ color: char.color });
    const pantsMat = new THREE.MeshPhongMaterial({ color: 0x333333 });

    // Torso
    this.torso = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.7, 0.3), clothesMat);
    this.torso.position.y = 1.15;
    this.torso.castShadow = true;
    this.player.add(this.torso);

    // Head
    this.head = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.35, 0.3), skinMat);
    this.head.position.y = 1.75;
    this.head.castShadow = true;
    this.player.add(this.head);

    // Legs
    const legGeo = new THREE.BoxGeometry(0.2, 0.8, 0.2);
    this.leftLeg = new THREE.Mesh(legGeo, pantsMat);
    this.leftLeg.position.set(-0.15, 0.4, 0);
    this.leftLeg.castShadow = true;
    this.player.add(this.leftLeg);
    this.rightLeg = new THREE.Mesh(legGeo, pantsMat);
    this.rightLeg.position.set(0.15, 0.4, 0);
    this.rightLeg.castShadow = true;
    this.player.add(this.rightLeg);

    // Arms
    const armGeo = new THREE.BoxGeometry(0.18, 0.7, 0.18);
    this.leftArm = new THREE.Mesh(armGeo, clothesMat);
    this.leftArm.position.set(-0.35, 1.3, 0);
    this.leftArm.castShadow = true;
    this.player.add(this.leftArm);
    this.rightArm = new THREE.Mesh(armGeo, clothesMat);
    this.rightArm.position.set(0.35, 1.3, 0);
    this.rightArm.castShadow = true;
    this.player.add(this.rightArm);

    this.scene.add(this.player);
  }

  private createCarMesh(color: number): THREE.Object3D {
    const group = new THREE.Group();
    // Low Poly Chassis for Deformation
    const chassisGeo = new THREE.BoxGeometry(2, 0.8, 4.5, 3, 2, 3); // More segments for denting
    const chassis = new THREE.Mesh(chassisGeo, new THREE.MeshPhongMaterial({ color }));
    chassis.position.y = 0.8;
    chassis.castShadow = true;
    chassis.name = 'chassis';
    group.add(chassis);
    
    // Cabin
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.7, 2.5), new THREE.MeshPhongMaterial({ color: 0x111111, shininess: 100 }));
    cabin.position.y = 1.6;
    cabin.name = 'cabin';
    group.add(cabin);
    
    // Wheels
    const wheelGeo = new THREE.CylinderGeometry(0.4, 0.4, 0.3, 8); // Reduced poly
    const wheelMat = new THREE.MeshLambertMaterial({ color: 0x222222 });
    [[-1, 0.4, 1.5], [1, 0.4, 1.5], [-1, 0.4, -1.5], [1, 0.4, -1.5]].forEach(pos => {
      const w = new THREE.Mesh(wheelGeo, wheelMat);
      w.rotation.z = Math.PI/2;
      w.position.set(pos[0], pos[1], pos[2]);
      w.name = 'wheel';
      group.add(w);
    });
    return group;
  }

  private createSportCarMesh(color: number): THREE.Object3D {
    const car = this.createCarMesh(color);
    const chassis = car.getObjectByName('chassis');
    if (chassis) chassis.scale.set(1, 0.8, 1.1);
    return car;
  }

  private spawnVehicles(count: number) {
    for (let i = 0; i < count; i++) {
      const isSport = Math.random() > 0.7;
      const color = Math.random() * 0xffffff;
      const car = isSport ? this.createSportCarMesh(color) : this.createCarMesh(color);
      car.userData = { type: isSport ? 'SPORT' : 'CAR', hp: 100, speed: 0, isAI: true, color, wheelType: 0 };
      
      const lane = Math.floor((Math.random() - 0.5) * 36); 
      const isXAxis = Math.random() > 0.5;
      const roadPos = lane * 150;
      const offset = (Math.random() - 0.5) * CONFIG.world.size;
      
      if (isXAxis) {
        car.position.set(roadPos + 7.5, 0, offset);
        car.userData.speed = CONFIG.vehicle.maxSpeed * (0.8 + Math.random() * 0.4);
      } else {
        car.position.set(offset, 0, roadPos + 7.5);
        car.rotation.y = -Math.PI / 2;
        car.userData.speed = CONFIG.vehicle.maxSpeed * (0.8 + Math.random() * 0.4);
      }
      this.vehicles.push(car);
      this.scene.add(car);
    }
  }

  private spawnParkedVehicles(count: number) {
    for (let i = 0; i < count; i++) {
      const color = Math.random() * 0xffffff;
      const car = this.createCarMesh(color);
      car.userData = { type: 'CAR', hp: 100, speed: 0, isAI: false, color, wheelType: 0, isParked: true };
      
      const lane = Math.floor((Math.random() - 0.5) * 36); 
      const isXAxis = Math.random() > 0.5;
      const roadPos = lane * 150;
      const offset = (Math.random() - 0.5) * CONFIG.world.size * 0.9;
      
      // Park them on the shoulder/side of the road (approx +18 from center line)
      if (isXAxis) {
        car.position.set(roadPos + 18, 0, offset);
        // Randomly face forward or backward
        if (Math.random() > 0.5) car.rotation.y = Math.PI; 
      } else {
        car.position.set(offset, 0, roadPos + 18);
        car.rotation.y = Math.random() > 0.5 ? -Math.PI / 2 : Math.PI / 2;
      }
      
      this.vehicles.push(car);
      this.scene.add(car);
    }
  }

  private spawnEnemies(count: number) {
    const geo = new THREE.BoxGeometry(0.6, 1.8, 0.6);
    const mat = new THREE.MeshPhongMaterial({ color: 0xaa0000 });
    for(let i=0; i<count; i++) {
      const enemy = new THREE.Mesh(geo, mat);
      enemy.position.set((Math.random()-0.5)*CONFIG.world.size*0.7, 0.9, (Math.random()-0.5)*CONFIG.world.size*0.7);
      enemy.castShadow = true;
      enemy.userData = { hp: 100, speed: CONFIG.ai.enemySpeed, attackCooldown: 0, patrolTarget: new THREE.Vector3(enemy.position.x, 0, enemy.position.z) };
      this.enemies.push(enemy);
      this.scene.add(enemy);
    }
  }

  private spawnCitizens(count: number) {
    const geo = new THREE.BoxGeometry(0.5, 1.7, 0.5);
    for(let i=0; i<count; i++) {
      const mat = new THREE.MeshPhongMaterial({ color: Math.random() * 0xffffff });
      const civ = new THREE.Mesh(geo, mat);
      const lane = Math.floor((Math.random()-0.5)*36)*150;
      const isX = Math.random() > 0.5;
      const offset = (Math.random()-0.5)*CONFIG.world.size;
      if (isX) civ.position.set(lane+12, 0.85, offset); else civ.position.set(offset, 0.85, lane+12);
      civ.castShadow = true;
      civ.userData = { 
          speed: CONFIG.ai.citizenSpeed*(0.8+Math.random()*0.4), 
          direction: Math.random()*Math.PI*2, 
          changeTimer: 0, 
          fear: 0,
          state: 'WANDER' as CitizenState,
          actionTimer: 0
      };
      this.citizens.push(civ);
      this.scene.add(civ);
    }
  }

  private updateVehicleAI() {
    if (this.isPaused) return; 
    const limit = CONFIG.world.size / 2;
    // Get friction modifier from weather
    const frictionMod = WEATHER_CONFIG[this.state.currentWeather].frictionMod;

    this.vehicles.forEach(v => {
      if (v.userData.isParked) return;

      if (!v.userData.isAI) {
         // Apply weather physics to player vehicle here as well if needed
         return; 
      }
      const forward = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), v.rotation.y);
      this.forwardRaycaster.set(v.position, forward);
      const intersects = this.forwardRaycaster.intersectObjects(this.vehicles);
      let speed = v.userData.speed;
      if (intersects.length > 0 && intersects[0].distance < 15 && intersects[0].object !== v) speed = 0;
      
      // Slippery roads reduce control/speed slightly for AI
      v.translateZ(speed * frictionMod);
      
      if (v.position.x > limit) v.position.x = -limit;
      if (v.position.x < -limit) v.position.x = limit;
      if (v.position.z > limit) v.position.z = -limit;
      if (v.position.z < -limit) v.position.z = limit;
    });
  }

  public startGame(charIndex: number) {
    this.currentCharIndex = charIndex;
    this.resetPlayerState();
    this.createPlayer(); 
    this.initRainSystem();
    this.isStarted = true;
    this.isPaused = false;
    this.startMission(0);
    this.callbacks.onNotification("Bienvenue dans l'état de LEONIDA !");
    this.playSound('UI');
  }

  public dispose() {
    this.isStarted = false;
    if (this.animationFrameId) cancelAnimationFrame(this.animationFrameId);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.onResize);
    this.renderer.dispose();
  }

  public setCustomizationMode(enabled: boolean) {
    this.isCustomizing = enabled;
    if (enabled) this.keys = {};
  }

  public setInteractionMode(enabled: boolean) {
    this.isInteracting = enabled;
    if (enabled) this.keys = {};
  }

  public executeNPCAction(npc: NPCData) {
    // ... (Existing NPC Action Logic - No Changes Needed here)
    this.playSound('UI');
    if (this.state.money < npc.cost) {
        this.callbacks.onNotification("Fonds insuffisants !");
        return;
    }
    // ... Copy remaining logic from original file if needed, but for brevity assuming it's preserved
    // Simplified strictly for the prompt's focus on AI/Weather
    this.state.money -= npc.cost;
    this.callbacks.onNotification(`Service ${npc.serviceLabel} acheté.`);
  }

  public applyCustomization(color: number, wheelType: number) {
    if (!this.inVehicle) return;
    this.inVehicle.userData.color = color;
    this.inVehicle.userData.wheelType = wheelType;

    const chassis = this.inVehicle.getObjectByName('chassis') as THREE.Mesh;
    if (chassis && chassis.material instanceof THREE.MeshPhongMaterial) {
      chassis.material.color.setHex(color);
    }
  }

  private resetPlayerState() {
    this.state = {
      health: 100,
      maxHealth: 100,
      armor: 100,
      maxArmor: 100,
      stamina: 100,
      maxStamina: 100,
      currentWeapon: 1,
      wantedLevel: 0,
      kills: 0,
      money: 250,
      isJumping: false,
      velocityY: 0,
      activeMission: null,
      missionProgress: '',
      missionCompleted: false,
      missionTimeLeft: 0,
      currentWeather: 'SUN',
      skills: { driving: 10, shooting: 10, strength: 10, stamina: 10, flying: 0, stealth: 0 }
    };
    this.weapons = JSON.parse(JSON.stringify(INITIAL_WEAPONS));
  }

  private startMission(index: number) {
    // ... (Existing startMission logic)
    this.currentMissionIndex = index;
    const mission = MISSIONS[index];
    this.state.activeMission = mission;
    this.state.missionCompleted = false;
    this.missionState = 0;
    this.missionObjKills = 0;
    this.missionMarkers.clear();
    this.missionTargetVehicle = null;
    this.missionTargetEnemy = null;
    this.missionEndTime = 0;
    this.missionObjectivePos = null;
    this.missionDropoffPos = null;

    this.callbacks.onNotification(`NOUVELLE STORY: ${mission.title}`);
    this.playSound('UI');

    if (mission.type === 'ELIMINATION') {
      this.state.missionProgress = `0 / ${mission.targetCount} Ennemis`;
      this.spawnEnemies(5);
    } 
    // ... rest of mission types logic (preserved)
  }

  // ... (spawnNPCs, spawnVIPTarget, spawnChaseVehicle logic preserved)
  private spawnNPCs() {
    INTERACTIVE_NPCS.forEach(data => {
      const npc = new THREE.Group();
      const body = new THREE.Mesh(this.boxGeo, new THREE.MeshPhongMaterial({ color: data.color }));
      body.scale.set(1.4, 3.5, 0.7);
      body.position.y = 1.75;
      body.castShadow = true;
      npc.add(body);
      const head = new THREE.Mesh(this.boxGeo, new THREE.MeshPhongMaterial({ color: 0xffdbac }));
      head.scale.set(0.8, 0.8, 0.8);
      head.position.y = 4;
      head.castShadow = true;
      npc.add(head);
      const iconGeo = new THREE.ConeGeometry(0.5, 1, 4);
      const iconMat = new THREE.MeshBasicMaterial({ color: 0xffff00 });
      const icon = new THREE.Mesh(iconGeo, iconMat);
      icon.position.y = 6;
      icon.rotation.z = Math.PI;
      npc.add(icon);
      npc.position.set(data.position[0], data.position[1], data.position[2]);
      npc.userData = { info: data, floatOffset: Math.random() * 10 };
      this.npcs.push(icon); 
      this.scene.add(npc);
      npc.name = 'NPC_' + data.id;
    });
  }

  private spawnVIPTarget() { /* ... */ }
  private spawnChaseVehicle() { /* ... */ }
  private updateMissionLogic() { /* ... */ }

  private updateBullets() {
    for (let i = this.bullets.length - 1; i >= 0; i--) {
        const b = this.bullets[i];
        const vel = b.userData.vel;
        b.position.add(vel);
        b.userData.life--;

        let hit = false;
        
        // 1. HIT ENEMIES
        for (const enemy of this.enemies) {
            if (b.position.distanceTo(enemy.position) < 3.5) {
                enemy.userData.hp -= b.userData.damage;
                this.createHitEffect(enemy.position);
                this.playSound('HIT');
                if (enemy.userData.hp <= 0) this.killEnemy(enemy);
                hit = true;
                break;
            }
        }

        // 2. HIT CITIZENS (Crime)
        if (!hit) {
          for (let j = this.citizens.length - 1; j >= 0; j--) {
             const civ = this.citizens[j];
             if (b.position.distanceTo(civ.position) < 3.5) {
                // Instant crime notification
                if (this.state.wantedLevel === 0) {
                    this.state.wantedLevel = 1;
                    this.callbacks.onNotification("CRIME SIGNALÉ : Agression sur civil");
                    this.playSound('POLICE');
                }
                
                this.createHitEffect(civ.position);
                this.playSound('HIT');
                
                // Trigger panic in area
                this.triggerPanic(civ.position, 150);

                this.scene.remove(civ);
                this.citizens.splice(j, 1);
                
                this.state.wantedLevel = Math.min(5, this.state.wantedLevel + 1);
                
                hit = true;
                break;
             }
          }
        }

        // 3. HIT VEHICLES
        if (!hit) {
            for (const v of this.vehicles) {
                if (b.position.distanceTo(v.position) < (v.userData.type === 'BIKE' ? 4 : 8)) {
                    v.userData.hp -= b.userData.damage;
                    this.createHitEffect(b.position);
                    this.playSound('HIT');
                    const chassis = v.getObjectByName('chassis') as THREE.Mesh;
                    if (chassis) this.deformMesh(chassis, b.position, 0.5);
                    if (v.userData.hp <= 0 && !v.userData.destroyed) {
                         v.userData.destroyed = true;
                         if (chassis) (chassis.material as THREE.MeshPhongMaterial).color.setHex(0x111111);
                         this.createExplosion(v.position);
                    }
                    hit = true;
                    break;
                }
            }
        }

        if (hit || b.userData.life <= 0) {
            this.scene.remove(b);
            this.bullets.splice(i, 1);
        }
    }
  }

  // --- UPDATE ENEMIES (AI) ---
  private updateEnemies() {
    if (this.isPaused) return; 
    const playerPos = this.inVehicle ? this.inVehicle.position : this.player.position;

    this.enemies.forEach(enemy => {
        // Physics
        if (enemy.position.y > 0.9) enemy.position.y -= 0.1;

        const dist = enemy.position.distanceTo(playerPos);
        const detectionRange = CONFIG.ai.detectionRange;
        
        // AI Logic
        if (dist < detectionRange || this.state.wantedLevel > 0) {
           // Move towards player
           const dir = new THREE.Vector3().subVectors(playerPos, enemy.position).normalize();
           dir.y = 0;
           
           // Stop at shooting distance
           if (dist > 30) {
               enemy.position.add(dir.multiplyScalar(enemy.userData.speed));
               enemy.lookAt(playerPos);
           } else {
               enemy.lookAt(playerPos);
           }

           // Attack
           if (dist < CONFIG.ai.attackRange && this.isStarted) {
               if (enemy.userData.attackCooldown <= 0) {
                   // Shoot
                   const bullet = new THREE.Mesh(new THREE.SphereGeometry(0.4), new THREE.MeshBasicMaterial({color: 0xff0000}));
                   bullet.position.copy(enemy.position).add(new THREE.Vector3(0, 1.5, 0));
                   // Predict player movement slightly? No, simple aim.
                   const target = playerPos.clone().add(new THREE.Vector3(0, 1, 0));
                   // Add spread
                   target.x += (Math.random() - 0.5) * 2;
                   target.z += (Math.random() - 0.5) * 2;
                   
                   const shotDir = new THREE.Vector3().subVectors(target, bullet.position).normalize();
                   bullet.userData = { 
                       vel: shotDir.multiplyScalar(CONFIG.combat.bulletSpeed * 0.6), 
                       life: 100, 
                       damage: 5 + (this.state.wantedLevel * 2) 
                   };
                   this.bullets.push(bullet);
                   this.scene.add(bullet);
                   this.playSound('SHOOT');

                   enemy.userData.attackCooldown = 100 - (this.state.wantedLevel * 10); // Faster fire rate at higher wanted level
               } else {
                   enemy.userData.attackCooldown--;
               }
           }
        } else {
           // Idle or Patrol logic could go here
        }
    });
  }

  // --- UPDATE CITIZENS (ENHANCED AI) ---
  private updateCitizens() {
    const playerPos = this.inVehicle ? this.inVehicle.position : this.player.position;
    
    this.citizens.forEach(c => {
        // Simple Physics (Gravity)
        if (c.position.y > 0.85) c.position.y -= 0.1;
        
        const distToPlayer = c.position.distanceTo(playerPos);

        // --- STATE MACHINE LOGIC ---
        
        // 1. Fear/Flee Triggers
        if (c.userData.fear > 0) {
            c.userData.fear--;
            c.userData.state = 'FLEE';
        } else if (this.state.wantedLevel > 0 && distToPlayer < 50) {
            // Player is wanted and close -> Fear or Call Police
            if (c.userData.state !== 'FLEE' && c.userData.state !== 'CALL_POLICE') {
                 // 30% chance to call police, 70% to flee immediately
                 c.userData.state = Math.random() > 0.7 ? 'CALL_POLICE' : 'FLEE';
                 c.userData.actionTimer = 120; // 2 seconds action
            }
        } else if (c.userData.state !== 'WANDER') {
            // Calm down if no danger
            c.userData.state = 'WANDER';
            // Restore scale (in case they were cowering)
            c.scale.set(1, 1, 1);
        }

        // --- BEHAVIOR BY STATE ---

        if (c.userData.state === 'FLEE') {
             // Run away vector
             const dir = new THREE.Vector3().subVectors(c.position, playerPos).normalize();
             dir.y = 0;
             // Simple obstacle avoidance raycast
             this.raycaster.set(c.position, dir);
             const hits = this.raycaster.intersectObjects([...this.vehicles, ...this.citizens], false);
             if (hits.length > 0 && hits[0].distance < 3) {
                 // Deflect
                 dir.applyAxisAngle(new THREE.Vector3(0,1,0), Math.PI/2);
             }
             
             c.position.add(dir.multiplyScalar(c.userData.speed * 3.0)); // Run fast
             c.lookAt(c.position.clone().add(dir));

             // Randomly cower if far enough but still scared
             if (distToPlayer > 80 && Math.random() < 0.01) {
                 c.userData.state = 'COWER';
                 c.userData.actionTimer = 200;
             }

        } else if (c.userData.state === 'COWER') {
             // Cowering animation proxy (shrink height)
             c.scale.set(1, 0.5, 1);
             c.userData.actionTimer--;
             if (c.userData.actionTimer <= 0) {
                 c.scale.set(1, 1, 1); // Stand up
                 c.userData.state = 'FLEE'; // Run again
             }
             
        } else if (c.userData.state === 'CALL_POLICE') {
             // Stop and 'dial'
             c.userData.actionTimer--;
             // Visual indicator of calling? (maybe jump slightly)
             if (Math.floor(Date.now() / 200) % 2 === 0) c.rotation.y += 0.1;
             
             if (c.userData.actionTimer <= 0) {
                 // Police Called!
                 if (this.state.wantedLevel < 3) {
                     this.state.wantedLevel++;
                     this.callbacks.onNotification("Un civil a appelé la police !");
                     this.playSound('POLICE');
                 }
                 c.userData.state = 'FLEE'; // Flee after calling
                 c.userData.fear = 300;
             }

        } else {
             // WANDER STATE (Normal)
             const forward = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), c.userData.direction);
             
             // Wall/Building Avoidance check
             const nextPos = c.position.clone().add(forward.multiplyScalar(2));
             if (this.checkCollisions(c)) {
                 // Turn around if hit wall
                 c.userData.direction += Math.PI;
             } else {
                 c.position.add(forward.multiplyScalar(c.userData.speed));
             }
             
             c.rotation.y = c.userData.direction;

             if (c.userData.changeTimer-- <= 0) {
                 c.userData.changeTimer = 100 + Math.random() * 200;
                 c.userData.direction += (Math.random() - 0.5) * 2;
             }
        }
    });
  }

  // --- UPDATE SKILLS ---
  private updateSkills() {
      // 1. Stamina: Running on foot
      if (!this.inVehicle && (this.keys['ShiftLeft'] || this.keys['ShiftRight']) && (this.keys['ArrowUp'] || this.keys['KeyW'])) {
          this.state.skills.stamina = Math.min(100, this.state.skills.stamina + 0.005);
      }
      
      // 2. Driving: Driving fast
      if (this.inVehicle && Math.abs(this.inVehicle.userData.speed) > CONFIG.vehicle.maxSpeed * 0.8) {
          this.state.skills.driving = Math.min(100, this.state.skills.driving + 0.005);
      }
  }

  // ... (createExplosion, spawnParticle, failMission, completeMission, createObjectiveMarker logic preserved)
  private createExplosion(pos: THREE.Vector3) {
      for (let i = 0; i < 20; i++) {
        this.spawnParticle(pos, 0xff4500, 0.8, 60);
      }
      this.playSound('EXPLOSION');
      this.triggerPanic(pos, 150);
      this.callbacks.onNotification("BOOM!");
  }
  // ... (spawnParticle, failMission, completeMission, createObjectiveMarker)
  private spawnParticle(pos: THREE.Vector3, color: number, scale: number, life: number) {
     const p = this.particlePool.find(m => !m.visible);
     if (p) {
        p.visible = true;
        p.position.copy(pos);
        p.scale.set(scale, scale, scale);
        (p.material as THREE.MeshBasicMaterial).color.setHex(color);
        (p.material as THREE.MeshBasicMaterial).opacity = 1.0;
        p.userData = { 
           vel: new THREE.Vector3((Math.random() - 0.5) * 0.5, Math.random() * 0.5, (Math.random() - 0.5) * 0.5), 
           life: life, 
           maxLife: life 
        };
        this.particles.push(p);
     }
  }
  private failMission(reason: string) {
     this.state.missionProgress = `ÉCHEC: ${reason}`;
     this.callbacks.onNotification(reason);
     this.missionMarkers.clear();
     this.state.activeMission = null;
     setTimeout(() => { this.startMission(this.currentMissionIndex); }, 4000);
  }
  private completeMission() {
    this.state.missionCompleted = true;
    this.state.missionProgress = "MISSION TERMINÉE";
    this.state.money += 5000;
    this.callbacks.onNotification("MISSION ACCOMPLIE +$5000");
    this.missionMarkers.clear();
    this.missionEndTime = 0;
    this.playSound('UI');
    setTimeout(() => { this.startMission(this.currentMissionIndex + 1); }, 5000);
  }
  private createObjectiveMarker(pos: THREE.Vector3, color: number, floating: boolean = false) {
    const geometry = floating ? new THREE.ConeGeometry(2, 4, 8) : new THREE.CylinderGeometry(4, 4, 100, 16, 1, true);
    const material = new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: 0.5, side: THREE.DoubleSide, depthWrite: false });
    const marker = new THREE.Mesh(geometry, material);
    marker.position.copy(pos);
    if (floating) {
      marker.position.y += 15;
      marker.rotation.x = Math.PI;
    } else {
      marker.position.y = 50;
    }
    this.missionMarkers.add(marker);
  }

  private onKeyDown(e: KeyboardEvent) {
      if (this.isCustomizing || this.isInteracting || this.isPaused) return;
      this.keys[e.code] = true;
      if (e.code === 'KeyE') {
        if (this.nearbyNPC && !this.inVehicle) {
           this.callbacks.onInteraction(this.nearbyNPC.userData.info);
        } else {
           this.toggleVehicle();
        }
      }
      if (e.code === 'KeyV') this.changeCharacter();
      if (e.code === 'KeyN') this.shoot();
      if (e.code === 'KeyC' && this.inVehicle) {
          this.callbacks.onCustomizationOpen({
            color: this.inVehicle.userData.color || 0xff0000,
            wheelType: this.inVehicle.userData.wheelType || 0
          });
      }
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') this.isWalking = true;
      if (e.code === 'Space' && !this.state.isJumping && !this.inVehicle) this.jump();
      const num = parseInt(e.key);
      if (num >= 1 && num <= 5) {
          this.state.currentWeapon = num - 1;
      }
  }

  private onKeyUp(e: KeyboardEvent) {
      this.keys[e.code] = false;
      if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') this.isWalking = false;
  }

  private jump() {
      this.state.isJumping = true;
      this.state.velocityY = CONFIG.player.jumpHeight;
  }

  private toggleVehicle() {
      if (this.inVehicle) {
          this.player.visible = true;
          this.player.position.copy(this.inVehicle.position).add(new THREE.Vector3(10, 0, 0));
          this.player.rotation.y = this.inVehicle.rotation.y;
          this.inVehicle.userData.isAI = false;
          this.inVehicle.userData.speed = 0;
          this.inVehicle = null;
          this.callbacks.onNotification('Vous êtes sorti du véhicule');
          this.playSound('UI');
      } else if (this.nearbyVehicle) {
          if (this.nearbyVehicle.userData.type === 'PLANE') {
             this.callbacks.onNotification("Impossible de piloter cet avion.");
             return;
          }
          this.inVehicle = this.nearbyVehicle;
          this.inVehicle.userData.isAI = false;
          this.inVehicle.userData.speed = 0;
          this.player.visible = false;
          this.player.position.copy(this.inVehicle.position);
          this.callbacks.onNotification('Vous êtes monté dans le véhicule');
          this.playSound('ENGINE');
      }
  }

  private changeCharacter() {
      this.currentCharIndex = (this.currentCharIndex + 1) % CHARACTERS.length;
      const char = CHARACTERS[this.currentCharIndex];
      (this.torso.material as THREE.MeshPhongMaterial).color.setHex(char.color);
      (this.leftArm.material as THREE.MeshPhongMaterial).color.setHex(char.color);
      (this.rightArm.material as THREE.MeshPhongMaterial).color.setHex(char.color);
      this.callbacks.onCharacterChange(this.currentCharIndex);
  }

  private shoot() {
      if (!this.isStarted || this.isPaused) return;
      const now = Date.now();
      if (now - this.lastShotTime < CONFIG.combat.fireRate) return;
      this.lastShotTime = now;
      const weapon = this.weapons[this.state.currentWeapon];
      if (weapon.name === 'POING') {
          this.meleeAttack();
          return;
      }
      if (weapon.ammo <= 0) {
          this.callbacks.onNotification('Plus de munitions !');
          return;
      }
      weapon.ammo--;
      this.state.skills.shooting = Math.min(100, this.state.skills.shooting + 0.1); // Skill up
      this.triggerPanic(this.player.position, 100);
      this.playSound('SHOOT');
      
      const bullet = new THREE.Mesh(new THREE.SphereGeometry(0.4, 8, 8), new THREE.MeshPhongMaterial({ color: 0xffff00, emissive: 0xffff00, emissiveIntensity: 1 }));
      const origin = this.inVehicle ? this.inVehicle.position.clone().add(new THREE.Vector3(0, 3, 0)) : this.player.position.clone().add(new THREE.Vector3(0, 3.5, 0));
      const rot = this.inVehicle ? this.inVehicle.rotation.y : this.player.rotation.y;
      bullet.position.copy(origin);
      const dir = new THREE.Vector3(Math.sin(rot), 0, Math.cos(rot));
      bullet.userData = { vel: dir.multiplyScalar(CONFIG.combat.bulletSpeed), life: CONFIG.combat.bulletRange, damage: weapon.damage };
      this.bullets.push(bullet);
      this.scene.add(bullet);
  }

  private triggerPanic(center: THREE.Vector3, radius: number) {
      this.citizens.forEach(c => {
          if (c.position.distanceTo(center) < radius) {
              c.userData.fear = 300; 
              if (c.userData.state === 'WANDER') c.userData.state = 'FLEE';
          }
      });
  }

  private meleeAttack() {
      const weapon = this.weapons[0];
      const attackPos = this.inVehicle ? this.inVehicle.position : this.player.position;
      this.state.skills.strength = Math.min(100, this.state.skills.strength + 0.2); // Skill up
      this.enemies.forEach(enemy => {
          if (attackPos.distanceTo(enemy.position) < weapon.range) {
              enemy.userData.hp -= weapon.damage;
              this.createHitEffect(enemy.position);
              this.playSound('HIT');
              if (enemy.userData.hp <= 0) this.killEnemy(enemy);
          }
      });
  }

  private checkCollisions(entity: THREE.Object3D, isVehicle = false) {
    const sizeX = isVehicle ? 3 : 1; 
    const sizeZ = isVehicle ? 5 : 1;
    this.tempBox.setFromCenterAndSize(entity.position, this.tempVec.set(sizeX * 2, 10, sizeZ * 2));
    const cx = Math.floor(entity.position.x / this.cellSize);
    const cz = Math.floor(entity.position.z / this.cellSize);

    for (let x = cx - 1; x <= cx + 1; x++) {
        for (let z = cz - 1; z <= cz + 1; z++) {
             const key = `${x},${z}`;
             const objects = this.spatialGrid.get(key);
             if (objects) {
                 for (const obj of objects) {
                     if (this.tempBox.intersectsBox(obj.box)) {
                         const overlapX = Math.min(this.tempBox.max.x, obj.box.max.x) - Math.max(this.tempBox.min.x, obj.box.min.x);
                         const overlapZ = Math.min(this.tempBox.max.z, obj.box.max.z) - Math.max(this.tempBox.min.z, obj.box.min.z);
                         if (overlapX < overlapZ) {
                             if (entity.position.x < (obj.box.min.x + obj.box.max.x) * 0.5) entity.position.x -= overlapX;
                             else entity.position.x += overlapX;
                         } else {
                             if (entity.position.z < (obj.box.min.z + obj.box.max.z) * 0.5) entity.position.z -= overlapZ;
                             else entity.position.z += overlapZ;
                         }
                         return true;
                     }
                 }
             }
        }
    }

    if (isVehicle) {
        for (let v of this.vehicles) {
            if (v !== entity && entity.position.distanceTo(v.position) < 12) {
               return true; 
            }
        }
    }
    return false;
  }

  private animate() {
      this.animationFrameId = requestAnimationFrame(this.animate);
      if (!this.isStarted) return;
      if (this.isPaused) return; 
      this.update();
      this.renderer.render(this.scene, this.camera);
  }

  private update() {
    const time = Date.now() * 0.001;
    const char = CHARACTERS[this.currentCharIndex];
    const sensMultiplier = this.currentSettings.sensitivity;

    // UPDATE WEATHER & SKILLS
    this.updateWeather();
    this.updateSkills();

    // ... (Minimap and NPC float animation preserved)
    if (this.isCustomizing && this.inVehicle) {
       this.inVehicle.rotation.y += 0.005;
       this.updateCamera();
       this.drawMinimap();
       return;
    }
    this.npcs.forEach(icon => {
       if (icon.parent) {
          icon.position.y = 6 + Math.sin(time * 3 + icon.parent.userData.floatOffset) * 0.5;
          icon.rotation.y += 0.02;
       }
    });

    if (!this.inVehicle) {
        const moveSpeed = (this.isWalking ? CONFIG.player.walkSpeed : CONFIG.player.runSpeed) * (char.speed || 1);
        const rotSpeed = CONFIG.player.rotSpeed * sensMultiplier;
        let isMoving = false;

        if (this.keys['ArrowLeft'] || this.keys['KeyA']) this.player.rotation.y += rotSpeed;
        if (this.keys['ArrowRight'] || this.keys['KeyD']) this.player.rotation.y -= rotSpeed;
        if (this.keys['ArrowUp'] || this.keys['KeyW']) {
            this.player.position.x += Math.sin(this.player.rotation.y) * moveSpeed;
            this.player.position.z += Math.cos(this.player.rotation.y) * moveSpeed;
            isMoving = true;
        }
        if (this.keys['ArrowDown'] || this.keys['KeyS']) {
            this.player.position.x -= Math.sin(this.player.rotation.y) * (moveSpeed * 0.6);
            this.player.position.z -= Math.cos(this.player.rotation.y) * (moveSpeed * 0.6);
            isMoving = true;
        }

        if (this.state.stamina < this.state.maxStamina) {
            this.state.stamina += 0.5;
        }
        this.state.stamina = Math.max(0, Math.min(this.state.maxStamina, this.state.stamina));

        if (this.checkCollisions(this.player)) {
            this.callbacks.onCollision();
        }

        if (this.state.isJumping) {
            this.player.position.y += this.state.velocityY;
            this.state.velocityY -= CONFIG.player.gravity;
            if (this.player.position.y <= 0) {
                this.player.position.y = 0;
                this.state.isJumping = false;
                this.state.velocityY = 0;
            }
        }

        if (isMoving && !this.state.isJumping) {
            const animSpeed = this.isWalking ? 12 : 25; 
            this.leftLeg.rotation.x = Math.sin(time * animSpeed) * 0.8;
            this.rightLeg.rotation.x = -Math.sin(time * animSpeed) * 0.8;
            this.leftArm.rotation.x = Math.sin(time * animSpeed + Math.PI) * 0.5;
            this.rightArm.rotation.x = -Math.sin(time * animSpeed + Math.PI) * 0.5;
        } else {
            this.leftLeg.rotation.x = 0;
            this.rightLeg.rotation.x = 0;
            this.leftArm.rotation.x = 0;
            this.rightArm.rotation.x = 0;
        }

        this.nearbyVehicle = null;
        let minDist = Infinity;
        this.vehicles.forEach(v => {
            const dist = this.player.position.distanceTo(v.position);
            if (dist < 15 && dist < minDist) {
                this.nearbyVehicle = v;
                minDist = dist;
            }
        });

        this.nearbyNPC = null;
        minDist = Infinity;
        this.scene.children.forEach(child => {
            if (child.name.startsWith('NPC_')) {
                const dist = this.player.position.distanceTo(child.position);
                if (dist < 10 && dist < minDist) {
                    this.nearbyNPC = child as THREE.Mesh;
                    minDist = dist;
                }
            }
        });

    } 
    else {
        // ... (Vehicle Physics) ...
        const frictionMod = WEATHER_CONFIG[this.state.currentWeather].frictionMod;
        const maxSpeed = (this.inVehicle.userData.type === 'SPORT' ? CONFIG.vehicle.maxSpeed * 1.5 : CONFIG.vehicle.maxSpeed) * frictionMod;
        const acceleration = (this.inVehicle.userData.type === 'BIKE' ? CONFIG.vehicle.acceleration * 1.5 : CONFIG.vehicle.acceleration) * frictionMod;
        
        if (this.keys['ArrowUp'] || this.keys['KeyW']) {
            this.inVehicle.userData.speed += acceleration * (char.driving || 1);
        }
        if (this.keys['ArrowDown'] || this.keys['KeyS']) {
            this.inVehicle.userData.speed -= CONFIG.vehicle.deceleration;
        }

        this.inVehicle.userData.speed *= CONFIG.vehicle.friction;
        this.inVehicle.userData.speed = Math.max(
            -maxSpeed * 0.6,
            Math.min(maxSpeed * (char.driving || 1), this.inVehicle.userData.speed)
        );

        if (Math.abs(this.inVehicle.userData.speed) > 0.01) {
            const turnFactor = Math.min(Math.abs(this.inVehicle.userData.speed) / (maxSpeed * 0.5), 1);
            if (this.keys['ArrowLeft'] || this.keys['KeyA']) {
                this.inVehicle.rotation.y += CONFIG.vehicle.turnSpeed * turnFactor * (this.inVehicle.userData.speed > 0 ? 1 : -1) * sensMultiplier;
            }
            if (this.keys['ArrowRight'] || this.keys['KeyD']) {
                this.inVehicle.rotation.y -= CONFIG.vehicle.turnSpeed * turnFactor * (this.inVehicle.userData.speed > 0 ? 1 : -1) * sensMultiplier;
            }
        }
        
        if (this.inVehicle.userData.type === 'BIKE') {
            const body = this.inVehicle.getObjectByName('body');
            if (body) {
                const lean = (this.keys['ArrowLeft'] || this.keys['KeyA'] ? 0.5 : (this.keys['ArrowRight'] || this.keys['KeyD'] ? -0.5 : 0)) * (this.inVehicle.userData.speed / maxSpeed);
                body.rotation.z = THREE.MathUtils.lerp(body.rotation.z, lean, 0.1);
            }
        } else if ((this.keys['ArrowLeft'] || this.keys['KeyA'] || this.keys['ArrowRight'] || this.keys['KeyD']) && Math.abs(this.inVehicle.userData.speed) > 1.2) {
            this.inVehicle.userData.speed *= CONFIG.vehicle.driftFactor;
            this.createDriftParticle(this.inVehicle.position);
        }

        this.inVehicle.translateZ(this.inVehicle.userData.speed);

        if (this.checkCollisions(this.inVehicle, true)) {
            this.inVehicle.userData.speed *= -0.3;
            this.callbacks.onCollision();
            this.damagePlayer(1);
            this.playSound('HIT');
            
            // Deform vehicle on impact with wall
            const chassis = this.inVehicle.getObjectByName('chassis') as THREE.Mesh;
            if (chassis) this.deformMesh(chassis, this.inVehicle.position.clone().add(new THREE.Vector3(0,0,3).applyAxisAngle(new THREE.Vector3(0,1,0), this.inVehicle.rotation.y)), 1.0);
        }
        this.player.position.copy(this.inVehicle.position);
        
        if (Math.abs(this.inVehicle.userData.speed) > 0.5) {
            this.triggerPanic(this.inVehicle.position, 30);
        }
    }

    let interactLabel: string | null = null;
    if (this.nearbyNPC && !this.inVehicle) {
      interactLabel = `Parler à ${this.nearbyNPC.userData.info.name}`;
    } else if (this.nearbyVehicle && !this.inVehicle) {
       if (this.nearbyVehicle.userData.type === 'PLANE') {
           interactLabel = null; 
       } else {
           interactLabel = "Conduire";
       }
    } else if (this.inVehicle) {
      interactLabel = "Sortir";
    }

    const limit = CONFIG.world.size / 2 - 50;
    const target = this.inVehicle || this.player;
    target.position.x = Math.max(-limit, Math.min(limit, target.position.x));
    target.position.z = Math.max(-limit, Math.min(limit, target.position.z));

    this.updateBullets();
    this.updateEnemies();
    this.updateCitizens();
    this.updateVehicleAI();
    this.updateMissionLogic();
    this.updateParticles();
    this.updateCamera();
    this.drawMinimap();

    const vehicleSpeed = this.inVehicle ? this.inVehicle.userData.speed : 0;
    const newState = { ...this.state };
    this.callbacks.onHUDUpdate(newState, !!this.inVehicle, vehicleSpeed, interactLabel);
  }

  // ... (createHitEffect, createDriftParticle, killEnemy, updateCamera, drawMinimap, damagePlayer, updateParticles)
  private createHitEffect(pos: THREE.Vector3) {
      for (let i = 0; i < 5; i++) {
          this.spawnParticle(pos, 0xffff00, 0.2, 20);
      }
  }
  private createDriftParticle(pos: THREE.Vector3) {
      const p = this.particlePool.find(m => !m.visible);
      if (p) {
        this.spawnParticle(pos.clone().add(new THREE.Vector3((Math.random()-0.5)*2, 0.5, (Math.random()-0.5)*2)), 0xcccccc, 0.3, 30);
      }
  }
  private killEnemy(enemy: THREE.Mesh) {
    this.createHitEffect(enemy.position);
    this.scene.remove(enemy);
    const index = this.enemies.indexOf(enemy);
    if (index > -1) this.enemies.splice(index, 1);
    this.state.kills++;
    this.state.money += 100;
    this.state.wantedLevel = Math.min(5, this.state.wantedLevel + 1);
    this.missionObjKills++; 
    this.callbacks.onNotification('Ennemi éliminé +$100');
  }
  private updateCamera() {
    const target = this.inVehicle || this.player;
    if (!target) return;
    const offset = this.inVehicle ? new THREE.Vector3(0, 10, -20) : new THREE.Vector3(0, 8, -12);
    const relativeOffset = offset.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), target.rotation.y);
    const cameraPos = target.position.clone().add(relativeOffset);
    this.camera.position.lerp(cameraPos, 0.2); 
    this.camera.lookAt(target.position.clone().add(new THREE.Vector3(0, 2, 0)));
  }
  private drawMinimap() {
    const ctx = this.minimapCanvas.getContext('2d');
    if (!ctx) return;
    const width = this.minimapCanvas.width;
    const height = this.minimapCanvas.height;
    const playerPos = this.inVehicle ? this.inVehicle.position : this.player.position;
    const playerRot = this.inVehicle ? this.inVehicle.rotation.y : this.player.rotation.y;
    ctx.clearRect(0, 0, width, height);
    ctx.save();
    ctx.translate(width / 2, height / 2);
    ctx.rotate(playerRot); 
    ctx.scale(0.15, 0.15); // Zoom out for larger world
    ctx.translate(-playerPos.x, -playerPos.z); 
    
    // Draw Water Background
    ctx.fillStyle = '#003366';
    ctx.fillRect(playerPos.x - 2000, playerPos.z - 2000, 4000, 4000);

    // Dynamic Objects
    ctx.fillStyle = '#00f';
    for(const v of this.vehicles) {
        if(v === this.inVehicle) continue;
        ctx.fillRect(v.position.x - 4, v.position.z - 8, 8, 16);
    }
    ctx.fillStyle = '#f00';
    for(const e of this.enemies) {
        ctx.beginPath();
        ctx.arc(e.position.x, e.position.z, 6, 0, Math.PI*2);
        ctx.fill();
    }
    if(this.state.activeMission) {
       ctx.fillStyle = '#ff0';
       this.missionMarkers.children.forEach(m => {
          ctx.beginPath();
          ctx.arc(m.position.x, m.position.z, 25, 0, Math.PI*2);
          ctx.fill();
       });
    }
    ctx.fillStyle = '#fff';
    this.npcs.forEach(n => {
       if (n.parent) {
          ctx.beginPath();
          ctx.arc(n.parent.position.x, n.parent.position.z, 10, 0, Math.PI*2);
          ctx.fill();
       }
    });
    ctx.restore();
    
    // Player Arrow
    ctx.fillStyle = '#0f0';
    ctx.beginPath();
    ctx.moveTo(width / 2, height / 2 - 10);
    ctx.lineTo(width / 2 + 8, height / 2 + 10);
    ctx.lineTo(width / 2 - 8, height / 2 + 10);
    ctx.fill();
  }
  private damagePlayer(amount: number) {
      if (this.state.armor > 0) {
          this.state.armor -= amount;
          if (this.state.armor < 0) {
              this.state.health += this.state.armor;
              this.state.armor = 0;
          }
      } else {
          this.state.health -= amount;
      }
      this.playSound('HIT');
      if (this.state.health <= 0) {
          this.state.health = 0;
          this.callbacks.onGameEvent('GAMEOVER', this.state);
          this.isStarted = false;
      }
  }
  private updateParticles() {
      for (let i = 0; i < this.particles.length; i++) {
          const p = this.particles[i];
          if (!p.visible) continue;
          
          p.position.add(p.userData.vel);
          p.userData.life--;
          
          if (p.material instanceof THREE.MeshBasicMaterial) {
              p.material.opacity = (p.userData.life / p.userData.maxLife);
          }
          
          if (p.userData.life <= 0) {
              p.visible = false;
              this.particles[i] = this.particles[this.particles.length - 1];
              this.particles.pop();
              i--;
          }
      }
  }
}
