import React from 'react';

interface CustomizationMenuProps {
  onClose: () => void;
  onColorChange: (color: number) => void;
  onWheelChange: (type: number) => void;
  currentColor: number;
}

const COLORS = [
  { name: 'Red', value: 0xff0000 },
  { name: 'Blue', value: 0x0000ff },
  { name: 'Green', value: 0x00ff00 },
  { name: 'Yellow', value: 0xffff00 },
  { name: 'Purple', value: 0xff00ff },
  { name: 'Cyan', value: 0x00ffff },
  { name: 'White', value: 0xffffff },
  { name: 'Black', value: 0x000000 },
  { name: 'Orange', value: 0xff8800 },
  { name: 'Pink', value: 0xff69b4 },
  { name: 'Gold', value: 0xffd700 },
  { name: 'Silver', value: 0xc0c0c0 },
];

const WHEELS = [
  { name: 'Standard', type: 0 },
  { name: 'Sport', type: 1 },
  { name: 'Offroad', type: 2 },
];

export const CustomizationMenu: React.FC<CustomizationMenuProps> = ({ 
  onClose, 
  onColorChange, 
  onWheelChange,
  currentColor 
}) => {
  return (
    <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-50 animate-slide-notif">
      <div className="bg-zinc-900 border-4 border-yellow-500 rounded-xl p-8 max-w-2xl w-full shadow-[0_0_50px_rgba(255,200,0,0.3)]">
        <h2 className="text-4xl font-black text-yellow-500 text-center mb-2 italic tracking-wider">LOS SANTOS CUSTOMS</h2>
        <div className="h-1 w-full bg-yellow-500 mb-6"></div>

        <div className="mb-8">
          <h3 className="text-xl text-white font-bold mb-4 uppercase">Peinture</h3>
          <div className="grid grid-cols-6 gap-3">
            {COLORS.map((c) => (
              <button
                key={c.name}
                onClick={() => onColorChange(c.value)}
                className={`
                  w-full aspect-square rounded-full border-2 transition-all hover:scale-110
                  ${currentColor === c.value ? 'border-white scale-110 ring-2 ring-yellow-500' : 'border-transparent'}
                `}
                style={{ backgroundColor: '#' + c.value.toString(16).padStart(6, '0') }}
                title={c.name}
              />
            ))}
          </div>
        </div>

        <div className="mb-8">
          <h3 className="text-xl text-white font-bold mb-4 uppercase">Roues & Kits</h3>
          <div className="flex gap-4">
            {WHEELS.map((w) => (
              <button
                key={w.name}
                onClick={() => onWheelChange(w.type)}
                className="flex-1 py-3 bg-zinc-800 border-2 border-zinc-600 rounded-lg text-white font-bold hover:bg-zinc-700 hover:border-yellow-500 transition-colors uppercase"
              >
                {w.name}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-4 bg-yellow-500 text-black font-black text-xl uppercase rounded-lg hover:bg-yellow-400 transition-colors shadow-lg"
        >
          Confirmer & Sortir
        </button>
      </div>
    </div>
  );
};
