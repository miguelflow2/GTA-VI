import React from 'react';

interface VictoryScreenProps {
  type: 'VICTORY' | 'GAMEOVER';
  money: number;
  onRestart: () => void;
}

export const VictoryScreen: React.FC<VictoryScreenProps> = ({ type, money, onRestart }) => {
  const isVictory = type === 'VICTORY';
  
  return (
    <div className="absolute top-0 left-0 w-full h-full bg-black/95 flex flex-col justify-center items-center z-[999]">
      <div className={`text-6xl md:text-8xl font-bold ${isVictory ? 'text-green-500 drop-shadow-[0_0_30px_#00ff00]' : 'text-red-600 drop-shadow-[0_0_30px_#ff0000]'} mb-6 text-center`}>
        {isVictory ? 'MISSION RÉUSSIE' : 'GAME OVER'}
      </div>
      
      <div className="text-2xl text-white mb-10 text-center max-w-2xl px-4">
        {isVictory 
          ? `Los Santos est en sécurité ! Argent gagné : $${money}`
          : 'Vous avez échoué à protéger la ville.'}
      </div>
      
      <button
        onClick={onRestart}
        className="px-12 py-4 text-2xl font-bold text-black bg-gradient-to-br from-green-500 to-green-600 rounded-xl hover:-translate-y-1 hover:shadow-[0_12px_40px_rgba(0,255,0,0.7)] transition-all duration-300 pointer-events-auto"
      >
        Recommencer
      </button>
    </div>
  );
};