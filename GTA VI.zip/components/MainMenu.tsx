import React, { useEffect, useState } from 'react';
import { CHARACTERS } from '../game/constants';
import { GoogleGenAI } from "@google/genai";

interface MainMenuProps {
  selectedChar: number;
  onSelectChar: (idx: number) => void;
  onStart: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({ selectedChar, onSelectChar, onStart }) => {
  const [bgImage, setBgImage] = useState<string | null>(null);
  const [charImages, setCharImages] = useState<string[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [errorMode, setErrorMode] = useState<boolean>(false);

  useEffect(() => {
    const generateAssets = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        // Generate Background
        const bgPromise = ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [{ text: 'A cinematic wide shot of a neon-soaked Vice City street at sunset. Stylized digital art style like a video game loading screen. Palm trees in silhouette against a vibrant pink and purple sky. A retro sports car parked in the foreground. High contrast, vaporwave aesthetic, 4k resolution.' }],
          },
          config: { imageConfig: { aspectRatio: "16:9" } },
        });

        // Generate Character Portraits
        const charPromises = CHARACTERS.map(char => 
          ai.models.generateContent({
             model: 'gemini-2.5-flash-image',
             contents: {
                parts: [{ text: char.description || `Portrait of video game character ${char.name}` }]
             },
             config: { imageConfig: { aspectRatio: "1:1" } }
          })
        );

        const results = await Promise.all([bgPromise, ...charPromises]);
        const [bgRes, ...charResults] = results;

        if (bgRes.candidates && bgRes.candidates[0].content.parts[0].inlineData) {
            setBgImage(`data:image/png;base64,${bgRes.candidates[0].content.parts[0].inlineData.data}`);
        }

        const images = charResults.map(res => {
            if (res.candidates && res.candidates[0].content.parts[0].inlineData) {
                return `data:image/png;base64,${res.candidates[0].content.parts[0].inlineData.data}`;
            }
            return '';
        });
        setCharImages(images);

      } catch (error: any) {
        // Handle Quota Limit gracefully
        if (error?.message?.includes('429') || error?.status === 'RESOURCE_EXHAUSTED' || JSON.stringify(error).includes('429')) {
            console.warn("Gemini API Quota Exceeded - Switching to default visual assets.");
        } else {
            console.error("Failed to generate assets:", error);
        }
        setErrorMode(true);
      } finally {
        setLoading(false);
      }
    };

    generateAssets();
  }, []);

  return (
    <div className="absolute top-0 left-0 w-full h-full flex flex-col justify-center items-center z-50 overflow-hidden">
      
      {/* Dynamic Background Layer */}
      <div className="absolute inset-0 z-0 bg-[#1a0b2e]">
        {bgImage ? (
          <img 
            src={bgImage} 
            alt="Generated Background" 
            className="w-full h-full object-cover animate-[pulseStar_10s_ease_infinite]" 
            style={{ animation: 'pulseStar 20s infinite alternate' }}
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-[#1a0b2e] via-[#43103e] to-[#000000]">
             {/* Abstract grid pattern fallback */}
             <div className="absolute inset-0" style={{ 
                 backgroundImage: 'linear-gradient(rgba(255, 0, 204, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 0, 204, 0.1) 1px, transparent 1px)',
                 backgroundSize: '50px 50px',
                 transform: 'perspective(500px) rotateX(60deg)',
                 transformOrigin: 'bottom'
             }}></div>
          </div>
        )}
        <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]"></div>
      </div>

      {/* Content Layer */}
      <div className="relative z-10 flex flex-col items-center w-full">
        
        <div className="text-8xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-b from-[#ff00cc] to-[#3333ff] drop-shadow-[0_0_15px_rgba(255,0,204,0.5)] tracking-widest mb-2 select-none scale-y-110" style={{ fontFamily: 'Inter' }}>
          GTA VI
        </div>
        
        <p className="text-3xl text-white tracking-[0.5em] font-bold mb-12 text-center px-4 drop-shadow-[0_0_10px_#fff]">
          LEONIDA STATE
        </p>

        {loading && (
          <div className="absolute top-10 right-10 flex items-center gap-2 text-pink-400 animate-pulse">
            <div className="w-4 h-4 border-2 border-pink-400 border-t-transparent rounded-full animate-spin"></div>
            <span className="text-xs uppercase tracking-widest">Génération des Assets IA...</span>
          </div>
        )}

        <div className="flex flex-col md:flex-row gap-12 mb-16">
          {CHARACTERS.map((char, index) => {
            const isSelected = selectedChar === index;
            const imgSrc = charImages[index];

            return (
              <div
                key={char.name}
                onClick={() => onSelectChar(index)}
                className={`
                  w-72 p-1 bg-black/60 border-2 rounded-2xl cursor-pointer transition-all duration-300 text-center backdrop-blur-md group relative overflow-hidden
                  ${isSelected 
                    ? 'border-[#ff00cc] scale-110 shadow-[0_0_50px_rgba(255,0,204,0.6)] bg-black/80' 
                    : 'border-zinc-700 hover:border-white hover:scale-105 hover:bg-black/70'}
                `}
              >
                <div className={`w-full h-64 overflow-hidden rounded-t-xl relative mb-4 ${imgSrc ? 'bg-zinc-900' : 'bg-gradient-to-b from-zinc-800 to-black'}`}>
                    {imgSrc ? (
                        <img src={imgSrc} className={`w-full h-full object-cover transition-transform duration-500 ${isSelected ? 'scale-110' : 'grayscale group-hover:grayscale-0'}`} alt={char.name} />
                    ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center relative overflow-hidden">
                            {/* Stylish fallback silhouette */}
                            <div className={`absolute inset-0 opacity-30 bg-gradient-to-tr ${index === 0 ? 'from-pink-600 to-purple-600' : 'from-blue-600 to-teal-600'}`}></div>
                            <div className="text-8xl drop-shadow-lg z-10 transform group-hover:scale-110 transition-transform">
                                {index === 0 ? '💃' : '🧢'}
                            </div>
                        </div>
                    )}
                    {/* Role Overlay */}
                     <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black to-transparent p-2 pt-8">
                        <div className="text-xs text-white/80 font-mono tracking-widest uppercase">{char.role}</div>
                     </div>
                </div>
                
                <div className={`text-4xl font-black text-white mb-4 uppercase italic ${isSelected ? 'text-[#ff00cc]' : ''}`}>
                  {char.name}
                </div>

                {/* Stats Bars */}
                <div className="px-6 pb-6 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-zinc-400 uppercase">
                        <span className="w-16 text-left">Vitesse</span>
                        <div className="flex-1 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-500" style={{ width: `${(char.speed || 1) * 70}%`}}></div>
                        </div>
                    </div>
                    <div className="flex items-center gap-2 text-xs font-bold text-zinc-400 uppercase">
                        <span className="w-16 text-left">Force</span>
                        <div className="flex-1 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                            <div className="h-full bg-red-500" style={{ width: `${(char.strength || 1) * 60}%`}}></div>
                        </div>
                    </div>
                </div>
              </div>
            );
          })}
        </div>

        <button
          onClick={onStart}
          disabled={loading}
          className={`group relative px-24 py-6 overflow-hidden rounded-full bg-gradient-to-r from-[#ff00cc] to-[#3333ff] shadow-[0_0_60px_rgba(50,50,255,0.6)] hover:-translate-y-1 hover:shadow-[0_0_100px_rgba(255,0,204,0.9)] transition-all duration-300 ${loading ? 'opacity-50 cursor-wait' : ''}`}
        >
          <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:animate-[slideNotif_1s_ease_infinite]"></div>
          <span className="relative text-4xl font-black text-white tracking-widest uppercase block transform skew-x-[-10deg]">
            {loading ? 'CHARGEMENT...' : 'LANCER'}
          </span>
        </button>

        <div className="absolute bottom-10 flex flex-col items-center gap-1">
            <div className="flex gap-4 text-white/40 text-[10px] tracking-widest uppercase">
                <span>Powered by Gemini Nano Banana</span>
                <span>•</span>
                <span>Inspiré par Rockstar Games</span>
            </div>
            {errorMode && (
                <div className="text-yellow-500/50 text-[10px] uppercase tracking-wider font-bold">
                    Mode Hors Ligne / Quota Atteint
                </div>
            )}
        </div>
      </div>
    </div>
  );
};