import React, { useEffect, useState } from 'react';
import { GameSettings } from '../types';
import { GoogleGenAI } from "@google/genai";

interface PauseMenuProps {
  onResume: () => void;
  onQuit: () => void;
  settings: GameSettings;
  onUpdateSettings: (s: GameSettings) => void;
}

export const PauseMenu: React.FC<PauseMenuProps> = ({ onResume, onQuit, settings, onUpdateSettings }) => {
  const [activeTab, setActiveTab] = useState<'MAP' | 'SETTINGS' | 'GAME'>('MAP');
  const [mapImage, setMapImage] = useState<string | null>(null);
  const [mapError, setMapError] = useState<boolean>(false);

  // Generate Map Background using Nano Banana
  useEffect(() => {
    const generateMap = async () => {
       if (mapImage || mapError) return; // Cache locally or stop if error
       try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            // Updated prompt for satellite style map
            parts: [{ text: "A highly detailed top-down satellite view game map of a fictional archipelago state like Florida Keys. Green islands, blue ocean, highway bridges connecting islands. UI overlay with GPS roads in yellow, player icon arrow. Video game map screen style, GTA V map style, high resolution." }],
          },
          config: { imageConfig: { aspectRatio: "16:9" } },
        });
        if (response.candidates && response.candidates[0].content.parts[0].inlineData) {
            setMapImage(`data:image/png;base64,${response.candidates[0].content.parts[0].inlineData.data}`);
        }
       } catch (e: any) {
           // Silence 429 errors to avoid console noise, just show fallback
           if (e?.message?.includes('429') || e?.status === 'RESOURCE_EXHAUSTED' || JSON.stringify(e).includes('429')) {
               console.warn("Map Generation: Quota Exceeded.");
           } else {
               console.error(e);
           }
           setMapError(true);
       }
    };
    if (activeTab === 'MAP') generateMap();
  }, [activeTab, mapImage, mapError]);

  return (
    <div className="absolute inset-0 z-[100] bg-black/90 flex flex-col font-sans">
      
      {/* Header */}
      <div className="h-20 bg-black flex items-center px-12 justify-between border-b border-white/20">
         <div className="text-4xl font-black italic text-white tracking-widest">PAUSE</div>
         <div className="flex gap-8 text-xl font-bold text-white/50">
            {['MAP', 'GAME', 'SETTINGS', 'STATS'].map(tab => (
                <button 
                  key={tab} 
                  onClick={() => setActiveTab(tab as any)}
                  className={`hover:text-white transition-colors uppercase ${activeTab === tab ? 'text-[#ff00cc] border-b-4 border-[#ff00cc]' : ''}`}
                >
                    {tab}
                </button>
            ))}
         </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 relative overflow-hidden flex">
          
          {/* MAP TAB */}
          {activeTab === 'MAP' && (
             <div className="w-full h-full relative bg-[#0f1923] flex items-center justify-center overflow-hidden">
                {mapImage ? (
                    <img src={mapImage} className="w-full h-full object-cover opacity-90" alt="Map" />
                ) : (
                    <div className="w-full h-full relative bg-[#081015]">
                        {/* Fallback Grid Map */}
                        <div className="absolute inset-0 opacity-20" style={{
                            backgroundImage: 'linear-gradient(#333 1px, transparent 1px), linear-gradient(90deg, #333 1px, transparent 1px)',
                            backgroundSize: '40px 40px'
                        }}></div>
                        
                        {/* Fake Islands (CSS Shapes) */}
                        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-[#1a2e22] rounded-full blur-xl opacity-60"></div>
                        <div className="absolute bottom-1/3 right-1/4 w-96 h-48 bg-[#1a2e22] rounded-full blur-xl opacity-60 rotate-12"></div>
                        
                        <div className="absolute inset-0 flex items-center justify-center">
                            {mapError ? (
                                <div className="text-white/30 font-mono text-sm tracking-widest uppercase border border-white/10 px-4 py-2 bg-black/50 backdrop-blur">
                                    Satellite Hors Ligne
                                </div>
                            ) : (
                                <div className="text-white/50 animate-pulse font-bold tracking-widest">CHARGEMENT SATELLITE...</div>
                            )}
                        </div>
                    </div>
                )}
                
                {/* Fake Map UI Elements mimicking the reference */}
                <div className="absolute top-8 left-8 flex flex-col gap-4">
                     <div className="bg-black/80 text-white px-4 py-2 font-bold border-l-4 border-yellow-500 uppercase tracking-widest text-sm">
                        🗺️ Legend
                     </div>
                     <div className="bg-black/60 p-4 rounded text-xs text-zinc-300 space-y-2 backdrop-blur-sm">
                        <div className="flex items-center gap-2"><span className="text-blue-400">▲</span> Player</div>
                        <div className="flex items-center gap-2"><span className="text-yellow-500">?</span> Main Mission</div>
                        <div className="flex items-center gap-2"><span className="text-green-500">🛒</span> Store</div>
                        <div className="flex items-center gap-2"><span className="text-purple-500">★</span> Activity</div>
                     </div>
                </div>
                
                {/* Compass */}
                <div className="absolute bottom-10 left-10 w-24 h-24 border-4 border-white/20 rounded-full flex items-center justify-center bg-black/40 backdrop-blur">
                    <div className="text-white font-serif text-2xl font-bold">N</div>
                </div>
             </div>
          )}

          {/* SETTINGS TAB */}
          {activeTab === 'SETTINGS' && (
              <div className="w-full h-full flex items-center justify-center bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]">
                  <div className="w-full max-w-2xl bg-black/50 backdrop-blur-xl p-10 rounded-xl border border-white/10">
                      <h2 className="text-3xl font-bold text-white mb-8 border-b border-white/20 pb-4">PARAMÈTRES</h2>
                      
                      <div className="space-y-8">
                          {/* Sensitivity */}
                          <div>
                              <div className="flex justify-between text-white mb-2 font-bold uppercase">Sensibilité Souris</div>
                              <input 
                                type="range" min="0.1" max="3.0" step="0.1"
                                value={settings.sensitivity}
                                onChange={(e) => onUpdateSettings({...settings, sensitivity: parseFloat(e.target.value)})}
                                className="w-full accent-[#ff00cc] h-2 bg-zinc-700 rounded-lg appearance-none cursor-pointer"
                              />
                              <div className="text-right text-[#ff00cc]">{settings.sensitivity.toFixed(1)}</div>
                          </div>

                          {/* Audio */}
                          <div>
                              <div className="flex justify-between text-white mb-2 font-bold uppercase">Volume Musique</div>
                              <input 
                                type="range" min="0" max="1" step="0.1"
                                value={settings.musicVolume}
                                onChange={(e) => onUpdateSettings({...settings, musicVolume: parseFloat(e.target.value)})}
                                className="w-full accent-[#ff00cc] h-2 bg-zinc-700 rounded-lg appearance-none cursor-pointer"
                              />
                          </div>

                          {/* Graphics */}
                          <div>
                              <div className="flex justify-between text-white mb-2 font-bold uppercase">Distance d'affichage</div>
                              <div className="flex gap-4">
                                  {['LOW', 'MEDIUM', 'HIGH'].map((level) => (
                                      <button
                                        key={level}
                                        onClick={() => onUpdateSettings({...settings, renderDistance: level as any})}
                                        className={`flex-1 py-3 rounded border font-bold ${settings.renderDistance === level ? 'bg-[#ff00cc] border-[#ff00cc] text-black' : 'border-zinc-600 text-zinc-400 hover:border-white'}`}
                                      >
                                          {level}
                                      </button>
                                  ))}
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          )}

           {/* GAME TAB (Menu) */}
           {activeTab === 'GAME' && (
              <div className="w-full h-full flex flex-col items-center justify-center gap-6 bg-black/80">
                  <button onClick={onResume} className="text-5xl font-black text-white hover:text-[#ff00cc] hover:scale-105 transition-all uppercase italic">
                      REPRENDRE
                  </button>
                  <button onClick={onQuit} className="text-5xl font-black text-white hover:text-red-500 hover:scale-105 transition-all uppercase italic">
                      QUITTER
                  </button>
              </div>
           )}

      </div>

      {/* Footer */}
      <div className="h-16 bg-black flex items-center px-12 justify-end gap-6 border-t border-white/20">
         <button onClick={onResume} className="px-8 py-2 bg-white text-black font-bold rounded uppercase hover:bg-[#ff00cc] transition-colors">
            Retour (ESC)
         </button>
      </div>
    </div>
  );
};