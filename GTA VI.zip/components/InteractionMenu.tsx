import React from 'react';
import { NPCData } from '../types';

interface InteractionMenuProps {
  npc: NPCData;
  onAction: (npc: NPCData) => void;
  onClose: () => void;
}

export const InteractionMenu: React.FC<InteractionMenuProps> = ({ npc, onAction, onClose }) => {
  return (
    <div className="absolute inset-0 bg-black/60 flex items-center justify-center z-50 animate-slide-notif">
      <div className="bg-zinc-900 border-4 border-blue-500 rounded-xl p-8 max-w-lg w-full shadow-[0_0_50px_rgba(0,100,255,0.4)] relative">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-zinc-500 hover:text-white text-xl font-bold"
        >
          ✕
        </button>

        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 rounded-full bg-blue-600 flex items-center justify-center text-3xl border-2 border-white">
            {npc.type === 'QUEST' && '🕴️'}
            {npc.type === 'VENDOR' && '🔫'}
            {npc.type === 'MEDIC' && '🚑'}
            {npc.type === 'MECHANIC' && '🔧'}
            {npc.type === 'BRIBE' && '🕵️'}
            {npc.type === 'BLACK_MARKET' && '🏴'}
            {npc.type === 'INFORMANT' && '👁️'}
            {npc.type === 'GAMBLER' && '🎲'}
            {npc.type === 'TRAINER' && '💪'}
            {npc.type === 'TAXI' && '🚕'}
          </div>
          <div>
            <h2 className="text-3xl font-black text-white uppercase">{npc.name}</h2>
            <div className="text-blue-400 font-bold tracking-wider text-sm">{npc.type}</div>
          </div>
        </div>

        <div className="bg-zinc-800 p-4 rounded-lg mb-8 border-l-4 border-blue-500">
          <p className="text-xl text-zinc-200 italic">"{npc.dialogue}"</p>
        </div>

        <button
          onClick={() => onAction(npc)}
          className="w-full py-4 bg-gradient-to-r from-blue-600 to-blue-500 text-white font-black text-xl uppercase rounded-lg hover:brightness-110 transition-all shadow-lg flex justify-between px-6 items-center group"
        >
          <span>{npc.serviceLabel}</span>
          <span className="bg-black/30 px-3 py-1 rounded text-green-400 group-hover:bg-black/50 transition-colors">
            {npc.cost > 0 ? `$${npc.cost}` : 'GRATUIT'}
          </span>
        </button>

        <div className="mt-4 text-center text-zinc-500 text-sm">
          Appuyez sur <span className="text-white font-bold">ÉCHAP</span> pour annuler
        </div>
      </div>
    </div>
  );
};
