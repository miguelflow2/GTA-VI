
import React, { useState } from 'react';
import { PlayerState, Character, SkillStats } from '../types';
import { INITIAL_WEAPONS } from '../game/constants';

interface HUDProps {
  playerState: PlayerState;
  character: Character;
  notification: string | null;
  isCollisionWarning: boolean;
  isInVehicle: boolean;
  speed: number;
  canInteract: string | null;
  onPause: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  playerState,
  character,
  notification,
  isCollisionWarning,
  isInVehicle,
  speed,
  canInteract,
  onPause
}) => {
  const currentWeapon = INITIAL_WEAPONS[playerState.currentWeapon];
  const activeMission = playerState.activeMission;
  const isWanted = playerState.wantedLevel > 0;
  const [showSkills, setShowSkills] = useState(false);

  const getWeatherIcon = (type: string) => {
    switch(type) {
      case 'SUN': return '☀️';
      case 'RAIN': return '🌧️';
      case 'FOG': return '🌫️';
      case 'STORM': return '⛈️';
      default: return '☀️';
    }
  };

  return (
    <div className="absolute top-0 left-0 w-full h-full pointer-events-none font-sans select-none">
      
      {/* Top Left: Character Info */}
      <div className="absolute top-6 left-6 flex flex-col gap-2 pointer-events-auto">
         <div 
           className="bg-gradient-to-r from-black/90 to-black/60 px-6 py-3 rounded-lg border-l-4 border-green-500 shadow-lg backdrop-blur-md skew-x-[-10deg] cursor-pointer hover:scale-105 transition-transform"
           onClick={() => setShowSkills(!showSkills)}
         >
            <div className="skew-x-[10deg]">
               <div className="text-2xl font-black text-white tracking-widest uppercase italic">{character.name}</div>
               <div className="text-xs font-bold text-zinc-400">{character.role}</div>
            </div>
         </div>
         
         {/* Skills Panel Toggle */}
         {showSkills && (
           <div className="bg-black/90 p-4 rounded-lg border border-zinc-700 w-64 animate-slide-notif">
              <h3 className="text-white font-bold mb-2 uppercase border-b border-zinc-700 pb-1">Compétences</h3>
              <SkillBar label="Conduite" value={playerState.skills.driving} />
              <SkillBar label="Tir" value={playerState.skills.shooting} />
              <SkillBar label="Endurance" value={playerState.skills.stamina} />
              <SkillBar label="Force" value={playerState.skills.strength} />
              <SkillBar label="Vol" value={playerState.skills.flying} />
           </div>
         )}
      </div>

      {/* Top Center: Mission Status */}
      {activeMission && (
        <div className="absolute top-8 left-1/2 -translate-x-1/2 flex flex-col items-center w-full max-w-xl">
          <div className="bg-black/80 px-10 py-2 rounded-full border border-yellow-500/30 shadow-[0_0_20px_rgba(255,200,0,0.2)] backdrop-blur-md mb-2 flex items-center gap-3">
            <span className="w-3 h-3 rounded-full bg-yellow-500 animate-pulse"></span>
            <span className="text-yellow-500 font-bold uppercase tracking-[0.2em] text-sm">Objectif Actuel</span>
            <span className="w-3 h-3 rounded-full bg-yellow-500 animate-pulse"></span>
          </div>
          
          <div className="flex flex-col items-center">
             <div className="text-white font-black text-2xl uppercase tracking-wide drop-shadow-md text-center bg-black/40 px-6 py-1 rounded-lg">
               {activeMission.title}
             </div>
             <div className="text-yellow-400 font-bold text-lg mt-1 tracking-wide bg-black/60 px-4 rounded">
                {playerState.missionProgress}
             </div>
          </div>

          {playerState.missionTimeLeft !== undefined && (
             <div className={`text-4xl font-black mt-2 drop-shadow-[0_4px_4px_rgba(0,0,0,0.8)] ${playerState.missionTimeLeft < 10 ? 'text-red-500 animate-ping' : 'text-white'}`}>
               {playerState.missionTimeLeft}s
             </div>
          )}
        </div>
      )}

      {/* Top Right: Pause Button & Wanted Level & Weather */}
      <div className="absolute top-6 right-6 flex flex-col items-end gap-4 pointer-events-auto">
        
        <div className="flex gap-4">
             {/* Weather Indicator */}
            <div className="bg-black/60 w-12 h-12 rounded-full flex items-center justify-center text-2xl border border-white/10 shadow-lg" title="Météo actuelle">
                {getWeatherIcon(playerState.currentWeather)}
            </div>

            {/* Pause Button */}
            <button 
              onClick={onPause}
              className="bg-black/80 hover:bg-white hover:text-black text-white border-2 border-white/20 rounded-full w-12 h-12 flex items-center justify-center transition-all duration-200 shadow-lg group"
              title="Pause / Paramètres"
            >
              <div className="flex gap-1 group-hover:scale-110 transition-transform">
                <div className="w-1.5 h-4 bg-current rounded-sm"></div>
                <div className="w-1.5 h-4 bg-current rounded-sm"></div>
              </div>
            </button>
        </div>

        {/* Wanted Level */}
        <div className={`flex flex-col items-end gap-1 p-4 rounded-xl transition-all duration-500 ${isWanted ? 'bg-red-950/60 border-2 border-red-600/50 shadow-[0_0_40px_rgba(255,0,0,0.4)]' : ''}`}>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map(i => (
              <span 
                key={i} 
                className={`text-4xl transition-all duration-300 transform ${
                  i <= playerState.wantedLevel 
                    ? 'text-red-500 drop-shadow-[0_0_15px_rgba(255,0,0,0.9)] scale-110 animate-pulse' 
                    : 'text-zinc-800 scale-90'
                }`}
              >
                ★
              </span>
            ))}
          </div>
          {isWanted && (
             <div className="text-red-500 font-black text-sm tracking-[0.5em] animate-pulse uppercase border-t border-red-500/30 pt-1 w-full text-center">
               Recherché
             </div>
          )}
        </div>
      </div>

      {/* Center: Dynamic Notification */}
      {notification && (
        <div className="absolute top-40 left-1/2 -translate-x-1/2 flex flex-col items-center animate-slide-notif z-50">
           <div className="bg-black/90 px-8 py-4 rounded-lg border-l-8 border-green-500 text-white shadow-[0_10px_40px_rgba(0,0,0,0.5)] flex items-center gap-4 min-w-[300px]">
              <span className="text-green-500 text-3xl">ⓘ</span>
              <span className="font-bold text-xl tracking-wide">{notification}</span>
           </div>
        </div>
      )}

      {/* Center Screen: Collision Warning */}
      {isCollisionWarning && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-6xl font-black text-red-600 animate-bounce drop-shadow-[0_0_30px_rgba(255,0,0,0.8)] skew-x-[-10deg] border-4 border-red-600 px-8 py-2 bg-black/50">
          IMPACT !
        </div>
      )}

      {/* Bottom Center: Interaction Prompt */}
      {canInteract && (
        <div className="absolute bottom-32 left-1/2 -translate-x-1/2 bg-gradient-to-r from-green-600 to-green-500 text-black px-8 py-3 rounded-full shadow-[0_0_30px_rgba(0,255,0,0.4)] flex items-center gap-4 animate-bounce transform hover:scale-105 transition-transform">
          <div className="bg-black text-white w-8 h-8 flex items-center justify-center rounded-full text-sm font-black border-2 border-white">E</div>
          <span className="font-black tracking-wider text-sm uppercase">{canInteract}</span>
        </div>
      )}

      {/* Bottom Right: Stats Panel */}
      <div className="absolute bottom-8 right-8 flex flex-col items-end gap-3 pointer-events-auto">
        
        {/* Speedometer */}
        {isInVehicle && (
          <div className="mb-2 text-right">
            <div className="flex items-baseline justify-end gap-2">
               <div className="text-7xl font-black text-white italic tracking-tighter drop-shadow-[0_4px_4px_rgba(0,0,0,0.8)] leading-none">
                 {speed}
               </div>
               <span className="text-2xl text-green-500 font-bold">KM/H</span>
            </div>
            <div className="w-full h-2 bg-zinc-800 rounded-full mt-1 overflow-hidden">
               <div 
                 className={`h-full transition-all duration-100 ${speed > 150 ? 'bg-red-500' : 'bg-green-500'}`} 
                 style={{ width: `${Math.min(100, (speed / 200) * 100)}%` }}
               />
            </div>
          </div>
        )}

        {/* Info Box */}
        <div className="bg-black/90 p-5 rounded-2xl backdrop-blur-md border border-zinc-700 shadow-2xl min-w-[260px]">
          
          {/* Bars */}
          <div className="space-y-3 mb-5">
             {/* Health */}
             <div className="flex items-center gap-3">
               <span className="text-lg">❤️</span>
               <div className="flex-1 h-3 bg-zinc-800 rounded-full overflow-hidden border border-zinc-700">
                 <div className="h-full bg-gradient-to-r from-red-600 to-red-500 transition-all duration-300" style={{ width: `${(playerState.health / playerState.maxHealth) * 100}%` }} />
               </div>
             </div>
             {/* Armor */}
             <div className="flex items-center gap-3">
               <span className="text-lg">🛡️</span>
               <div className="flex-1 h-3 bg-zinc-800 rounded-full overflow-hidden border border-zinc-700">
                 <div className="h-full bg-gradient-to-r from-blue-600 to-blue-500 transition-all duration-300" style={{ width: `${(playerState.armor / playerState.maxArmor) * 100}%` }} />
               </div>
             </div>
             {/* Stamina */}
             <div className="flex items-center gap-3">
               <span className="text-lg">⚡</span>
               <div className="flex-1 h-3 bg-zinc-800 rounded-full overflow-hidden border border-zinc-700">
                 <div className="h-full bg-gradient-to-r from-yellow-500 to-yellow-400 transition-all duration-300" style={{ width: `${(playerState.stamina / playerState.maxStamina) * 100}%` }} />
               </div>
             </div>
          </div>

          {/* Money & Ammo Grid */}
          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-zinc-700">
            <div>
              <div className="text-xs text-zinc-400 uppercase tracking-wider mb-1">Cash</div>
              <div className="text-green-400 font-black text-xl tracking-wide">
                ${playerState.money.toLocaleString()}
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-zinc-400 uppercase tracking-wider mb-1">{currentWeapon.name}</div>
              <div className="text-white font-black text-xl">
                 {currentWeapon.ammo === Infinity ? '∞' : `${currentWeapon.ammo}/${currentWeapon.maxAmmo}`}
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

const SkillBar: React.FC<{ label: string; value: number }> = ({ label, value }) => (
  <div className="flex flex-col mb-2">
    <div className="flex justify-between text-xs text-zinc-400 uppercase font-bold mb-1">
      <span>{label}</span>
      <span>{Math.floor(value)}/100</span>
    </div>
    <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
      <div className="h-full bg-white transition-all duration-500" style={{ width: `${Math.min(100, value)}%` }}></div>
    </div>
  </div>
);
